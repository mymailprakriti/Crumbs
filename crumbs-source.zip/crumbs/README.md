# Crumbs 🍞

A lightweight personal ledger for tracking "crumb savings" — the guilt-free money left over after your main savings, bills, and essentials are handled. Crumbs never touches your main savings, investments, or bills; it only tracks the small stuff you choose to set aside.

Built with React + Vite + Tailwind CSS v4, everything persisted to `localStorage`. No backend, no login.

## Running it

```bash
npm install
npm run dev      # local dev server
npm run build    # production build -> dist/index.html (single self-contained file)
npm run preview  # preview the production build
```

`npm run build` produces one fully self-contained `dist/index.html` (via `vite-plugin-singlefile`) — you can open that file directly in a browser, or host it anywhere that serves static files.

## Project structure

```
src/
  components/   DashboardCard, AddCrumbModal, WishlistCard, TransactionItem,
                 PlannerSection, PurchaseSimulator, BottomNav, QuickCalculator,
                 WishlistItemModal, ItemDetailSheet, ProgressBar, PillFilter,
                 EmptyState, primitives (Card/Button/Chip — shared building blocks)
  screens/      Dashboard, Wishlist, Planner, Wallet, Settings
  utils/        calculations.js (every formula from the spec), currency.js,
                 storage.js (localStorage + export/import), week.js, id.js
  data/         initialData.js (crumb source options, wishlist categories)
  theme.js      Single source of truth for colors, shadows, radius, border
                 width — restyle the whole app by editing this file and its
                 CSS mirror in src/index.css's @theme block.
```

## Restyling

All visual tokens (colors, corner radius, border width, the sticker-style
drop shadow) live in two places that mirror each other:

- `src/theme.js` — JS constants, used for dynamic color choices (priority,
  category, transaction source) that Tailwind can't express with static
  classes.
- `src/index.css`'s `@theme` block — generates the Tailwind utilities
  (`bg-yellow`, `shadow-sticker-md`, `rounded-chunky-lg`, etc.) that
  components use directly.

Change a value in both places to reskin the app without touching component
code.

## Data model

```js
// Transaction
{ id, type: 'deposit' | 'spend', amount, source, note, date, category,
  budgetImpact, linkedWishlistItemId, resistedAmount?, rewardPercentage? }

// WishlistItem
{ id, name, price, category, priority, link, notes, image, createdAt,
  targetDate, status: 'active' | 'bought' | 'archived' }

// Settings
{ currency, weeklyBudget, savingRateMode: 'manual' | 'auto',
  manualWeeklyCrumbRate }
```

Everything is stored under a single `localStorage` key (see
`src/utils/storage.js`), so export/import/reset are simple, atomic
operations. Settings → "Export data as JSON" / "Import data from JSON" /
"Reset data" cover backup and recovery.

## A note on the one non-obvious design choice

The spec's weekly-budget formulas need a "spent so far this week" number,
but Crumbs deliberately doesn't track your whole budget — only crumbs. So
that one number is the single manual input in the app (editable right on
the Dashboard); everything else (instant crumbs from budget, money
protected, crumb balance, ETAs) is derived automatically from your crumb
transactions.

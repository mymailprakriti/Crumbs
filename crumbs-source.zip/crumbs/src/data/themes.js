// Selectable color themes for the whole app (see Settings > Appearance).
// Each theme supplies the same 15 tokens defined in src/theme.js /
// src/index.css's @theme block; applying a theme just overrides those CSS
// custom properties at runtime (see utils/applyTheme.js) — every existing
// bg-yellow / text-green-dark / border-ink class across the app already
// reads from these variables, so nothing else has to change per-theme.
//
// New themes are built with `buildTheme`, which takes the exact reference
// hex values from a moodboard and cycles them across the app's six accent
// slots UNCHANGED — no hue/lightness/saturation adjustment — so what you
// pick in Settings is exactly what was in the picture. Only the "-dark"
// variant (used as small bold TEXT sitting on the paper/cream background,
// e.g. "Guilt-free buy" labels, links — never shown as a swatch itself) is
// derived via `textSafeAccent`, purely so that text stays legible; it never
// touches the visible swatch color itself.
import { textSafeAccent, getContrastText } from '../utils/color'

const SLOTS = ['yellow', 'green', 'coral', 'pink', 'blue', 'purple']

function buildTheme({ id, name, mode, cream, paper, ink, hues }) {
  const colors = { cream, paper, ink }
  SLOTS.forEach((slot, i) => {
    const seed = hues[i % hues.length]
    colors[slot] = seed
    colors[`${slot}Dark`] = textSafeAccent(seed, mode)
  })
  return { id, name, mode, colors }
}

// Some exact reference swatches (and their derived "-dark" text partners)
// land quite dark — e.g. a burnt gray or a deep brown used as an accent
// fill. Wherever that accent is drawn as a full surface with text sitting
// directly on it (folder tiles, pills, buttons), plain ink text would
// disappear. `{slot}On` / `{slot}DarkOn` are the WCAG-luminance-picked
// black/white label colors for each accent — see the CSS pairing rules in
// index.css that apply them automatically to any bg-{accent} surface.
function withContrastTokens(theme) {
  const c = theme.colors
  SLOTS.forEach((slot) => {
    c[`${slot}On`] = getContrastText(c[slot])
    c[`${slot}DarkOn`] = getContrastText(c[`${slot}Dark`])
  })
  return theme
}

export const THEMES = [
  {
    id: 'classic',
    name: 'Classic',
    mode: 'light',
    colors: {
      cream: '#F7F1E3',
      paper: '#FFFCF5',
      ink: '#171310',
      yellow: '#F3D386',
      yellowDark: '#E4B443',
      green: '#64BC9A',
      greenDark: '#258660',
      coral: '#F2A191',
      coralDark: '#DA6D58',
      pink: '#F2BFD6',
      pinkDark: '#D4689A',
      blue: '#89A9CA',
      blueDark: '#477BAF',
      purple: '#BCACDF',
      purpleDark: '#8E72C8',
    },
  },

  // Midnight / Lionsmane / Celeste / Herb / Marigold — accents are the
  // 3 literal moodboard hues (Marigold, Herb, Celeste), cycled across the
  // 6 slots exactly as given.
  buildTheme({
    id: 'midnight-marigold',
    name: 'Midnight Marigold',
    mode: 'light',
    cream: '#FCF3E3',
    paper: '#FFFDF8',
    ink: '#013D5A',
    hues: ['#F4A258', '#708C69', '#BDD3CE'],
  }),

  // Navy / Cloud / Periwinkle / Maroon / Peach — accents are the 3 literal
  // moodboard hues (Periwinkle, Maroon, Peach), cycled across the 6 slots.
  buildTheme({
    id: 'navy-peach',
    name: 'Navy Peach',
    mode: 'light',
    cream: '#FFFCF5',
    paper: '#FFFFFF',
    ink: '#374375',
    hues: ['#BABDE2', '#895159', '#DFAEA1'],
  }),

  // Perfumery / Apricot Jam / Albuquerque / Spring Solstice / Film Camera /
  // Dirty Martini — 5 literal moodboard hues, cycled across the 6 slots.
  buildTheme({
    id: 'terracotta',
    name: 'Terracotta',
    mode: 'light',
    cream: '#F9ECE8',
    paper: '#FFFCFA',
    ink: '#4A2F22',
    hues: ['#F4C2AE', '#D0634C', '#D3DCD7', '#D49066', '#939685'],
  }),

  // Светлый голубой / Светлый зеленый / Светлый фиолетовый / Светлый розовый
  // / Светлый серый / Выгоревший серый — 4 literal accent hues, cycled
  // across the 6 slots; the burnt gray doubles as ink, the light gray as
  // cream/paper.
  buildTheme({
    id: 'pastel-sky',
    name: 'Pastel Sky',
    mode: 'light',
    cream: '#F8F6F5',
    paper: '#FFFFFF',
    ink: '#5D5D5A',
    hues: ['#CDEBF1', '#DEF1D0', '#CBCEEA', '#F8E5E5'],
  }),

  // Нежный фиолетовый / Светлый розовый / Спокойный белый / Нежный
  // оранжевый / Яркий коричневый / Светлый бежевый — 4 literal accent
  // hues, cycled across the 6 slots; the deep brown doubles as ink.
  buildTheme({
    id: 'cocoa-blossom',
    name: 'Cocoa Blossom',
    mode: 'light',
    cream: '#FCF9F9',
    paper: '#FFFFFF',
    ink: '#654633',
    hues: ['#EAEAF4', '#FEDEE9', '#FFB98D', '#F8E5E5'],
  }),
].map(withContrastTokens)

export function getTheme(id) {
  return THEMES.find((t) => t.id === id) || THEMES[0]
}

// A rotating daily line under the Dashboard heading. Deterministic by
// calendar day (not random) so it stays put for the whole day and is the
// same across a refresh — see utils/quotes.js.
export const dailyQuotes = [
  "Small crumbs, saved on purpose, add up to something real.",
  "You don't need a big win today. A skipped coffee counts too.",
  "Guilt-free doesn't mean careless — it means intentional.",
  "The money you didn't spend is still your money.",
  "Future-you says thanks for the ₹50 you didn't need to spend.",
  "Every crumb is a tiny vote for the thing you actually want.",
  "Saving isn't about restriction. It's about choosing on purpose.",
  "A little restraint today buys a little joy later.",
  "You're not depriving yourself. You're deciding for yourself.",
  "Patience is just saving with better timing.",
  "The best purchases are the ones you didn't have to regret.",
  "Not spending it is a decision. Give yourself credit for it.",
  "Slow and steady still buys the headphones.",
  "Treat yourself later by being a little kind to yourself now.",
  "A rupee resisted is a rupee redirected, not a rupee lost.",
  "You're allowed to want things and still wait for them well.",
  "Every crumb jar starts with one crumb.",
  "It's not about never spending — it's about spending on purpose.",
  "The smallest habits are the ones that actually stick.",
  "Today's leftover is tomorrow's guilt-free buy.",
  "You already did the hard part — you noticed the choice.",
  "Nobody regrets the money they quietly set aside.",
  "Small and consistent beats big and occasional.",
  "This is your money, working exactly the way you want it to.",
  "A skipped splurge is just a future splurge with better timing.",
  "You don't need permission to be proud of ₹50.",
  "Progress on a savings goal looks boring. That's the point.",
  "The crumb jar doesn't judge — it just adds up.",
  "Wanting things and being patient about them can both be true.",
  "Every 'not yet' is one step closer to 'yes, guilt-free'.",
]

function dayOfYear(date) {
  const start = new Date(date.getFullYear(), 0, 0)
  return Math.floor((date - start) / 86400000)
}

export function getDailyQuote(date = new Date()) {
  return dailyQuotes[dayOfYear(date) % dailyQuotes.length]
}

// Small, witty stand-ins for the Dashboard's big headline — rotates daily
// (same day-of-year trick as the quote below it) instead of always saying
// "Ready to save?".
export const dailyHeadlines = [
  'Ready to save?',
  'Snack less, stack more.',
  'Crumbs, assemble.',
  'Save now, brag later.',
  'Guilt-free mode: on.',
  'Coins are calling.',
  'Tiny wins, big jar.',
  'Stack those crumbs.',
  'Small leaks, big saves.',
  "Your jar's growing.",
  'Small change, big change.',
  'Crumbs beat guilt.',
  'Quietly getting richer.',
  'Nice save.',
  'Look at you, saving.',
  'Every crumb counts.',
  "Jar's filling up nicely.",
  'Keep the crumbs coming.',
  'Small stacks, big flex.',
  'Save smart. Spend smarter.',
  'Future you says thanks.',
  'Patience, but make it cute.',
  'Money moves, quietly.',
  'One crumb closer.',
  'Today: a little richer.',
]

export function getDailyHeadline(date = new Date()) {
  return dailyHeadlines[dayOfYear(date) % dailyHeadlines.length]
}

// Optional starter content shown only on a completely empty first run, so
// the app doesn't feel dead. Purely illustrative — Settings > Reset data
// wipes it just like anything else. Not auto-seeded (see App.jsx); the
// user opts in from the empty state instead.

export const sampleWishlist = [
  {
    id: 'sample-1',
    name: 'Sony WH-CH720N Headphones',
    price: 7000,
    category: 'Gadgets',
    priority: 'medium',
    link: '',
    notes: '',
    image: '',
    createdAt: new Date().toISOString(),
    targetDate: null,
    status: 'active',
  },
  {
    id: 'sample-2',
    name: 'Weekend Trip to Goa',
    price: 12000,
    category: 'Travel',
    priority: 'high',
    link: '',
    notes: 'With the usual crew',
    image: '',
    createdAt: new Date().toISOString(),
    targetDate: null,
    status: 'active',
  },
  {
    id: 'sample-3',
    name: 'New Sneakers',
    price: 3500,
    category: 'Clothing',
    priority: 'low',
    link: '',
    notes: '',
    image: '',
    createdAt: new Date().toISOString(),
    targetDate: null,
    status: 'active',
  },
]

export const crumbSourceGroups = [
  {
    key: 'from_budget',
    title: 'From this week’s budget',
    subtitle: 'This reduces what you have left to spend this week.',
    options: [
      { value: 'skipped_food', label: 'Didn’t order food', category: 'Food' },
      { value: 'skipped_coffee', label: 'Skipped coffee', category: 'Food' },
      { value: 'skipped_cab', label: 'Skipped a cab', category: 'Travel' },
      { value: 'avoided_impulse', label: 'Avoided impulse shopping', category: 'Other' },
      { value: 'spent_less', label: 'Spent less than planned', category: 'Other' },
      { value: 'cheaper_alt', label: 'Bought a cheaper alternative', category: 'Other' },
    ],
  },
  {
    key: 'outside_budget',
    title: 'Outside this week’s budget',
    subtitle: 'This doesn’t touch your weekly spendable money.',
    options: [
      { value: 'refund', label: 'Refund', category: 'Other' },
      { value: 'cashback', label: 'Cashback', category: 'Other' },
      { value: 'sold_item', label: 'Sold an item', category: 'Other' },
      { value: 'gift', label: 'Gift', category: 'Other' },
      { value: 'extra_income', label: 'Extra income', category: 'Other' },
      { value: 'reimbursement', label: 'Reimbursement', category: 'Other' },
      { value: 'manual', label: 'Just add money', category: 'Other' },
    ],
  },
]

// Default wishlist categories, seeded once into app state and fully
// editable from there after (see CategoryManagerModal + utils/storage.js).
export const defaultCategories = [
  { id: 'cat_food', name: 'Food', color: 'coral' },
  { id: 'cat_travel', name: 'Travel', color: 'blue' },
  { id: 'cat_gadgets', name: 'Gadgets', color: 'purple' },
  { id: 'cat_clothing', name: 'Clothing', color: 'pink' },
  { id: 'cat_hobbies', name: 'Hobbies', color: 'green' },
  { id: 'cat_health', name: 'Health', color: 'green' },
  { id: 'cat_other', name: 'Other', color: 'yellow' },
]

// ─────────────────────────────────────────────────────────────────────────
// CRUMBS · THEME CONFIG
// This is the single source of truth for the visual language of the app.
// Change a value here (and its mirror in src/index.css under the @theme
// block) to restyle the whole app — colors, chunky border width, corner
// radius, and the sticker-style drop shadow are all defined once.
//
// Components should pull colors for *dynamic* things (priority, category,
// transaction type) from the maps below rather than hardcoding hex values.
// Static layout colors (backgrounds, borders, text) should use the Tailwind
// utility classes generated from src/index.css's @theme block instead
// (e.g. `bg-cream`, `border-ink`, `shadow-sticker`).
// ─────────────────────────────────────────────────────────────────────────

export const theme = {
  radius: {
    sm: '12px',
    md: '18px',
    lg: '24px',
    pill: '999px',
  },
  border: {
    width: '3px',
    widthThick: '4px',
    color: '#171310',
  },
  shadow: {
    // hard, offset, sticker-like — no blur
    sm: '3px 3px 0px #171310',
    md: '5px 5px 0px #171310',
    lg: '7px 7px 0px #171310',
  },
  colors: {
    cream: '#F7F1E3',
    creamDark: '#EFE6D3',
    ink: '#171310',
    paper: '#FFFCF5',
    yellow: '#F3D386',
    yellowDark: '#E4B443',
    green: '#64BC9A',
    greenDark: '#258660',
    coral: '#F2A191',
    coralDark: '#DA6D58',
    pink: '#F2BFD6',
    pinkDark: '#D4689A',
    blue: '#89A9CA',
    blueDark: '#477BAF',
    purple: '#BCACDF',
    purpleDark: '#8E72C8',
  },
}

// Priority → accent color key (used for chips + card left-borders)
export const priorityColor = {
  high: 'coral',
  medium: 'yellow',
  low: 'blue',
}

export const priorityLabel = {
  high: 'High priority',
  medium: 'Medium priority',
  low: 'Low priority',
}

// Categories are user-editable, so their colors live in app state (see
// utils/categories.js + data/initialData.js's defaultCategories) rather
// than a fixed map here.

// Crumb source → accent color for wallet/transaction list. Keys match the
// reason `value`s in src/data/initialData.js's crumbSourceGroups, plus a
// couple of system-generated sources (wishlist_purchase, weekly_leftover,
// manual_spend).
export const sourceColor = {
  skipped_food: 'green',
  skipped_coffee: 'green',
  skipped_cab: 'green',
  avoided_impulse: 'green',
  spent_less: 'green',
  cheaper_alt: 'green',
  refund: 'blue',
  cashback: 'blue',
  sold_item: 'purple',
  gift: 'pink',
  extra_income: 'yellow',
  reimbursement: 'blue',
  manual: 'yellow',
  wishlist_purchase: 'coral',
  weekly_leftover: 'green',
  manual_spend: 'coral',
}

export const sourceLabel = {
  skipped_food: 'Didn’t order food',
  skipped_coffee: 'Skipped coffee',
  skipped_cab: 'Skipped a cab',
  avoided_impulse: 'Avoided impulse shopping',
  spent_less: 'Spent less than planned',
  cheaper_alt: 'Bought a cheaper alternative',
  refund: 'Refund',
  cashback: 'Cashback',
  sold_item: 'Sold an item',
  gift: 'Gift',
  extra_income: 'Extra income',
  reimbursement: 'Reimbursement',
  manual: 'Manual addition',
  wishlist_purchase: 'Wishlist purchase',
  weekly_leftover: 'Weekly leftover',
  manual_spend: 'Manual spend',
}

export default theme

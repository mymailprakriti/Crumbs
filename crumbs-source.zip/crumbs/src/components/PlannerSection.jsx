import WishlistCard from './WishlistCard'
import { bgClass } from './primitives'

export default function PlannerSection({ title, subtitle, accent, entries, categories, crumbBalance, onSelectItem }) {
  if (!entries.length) return null

  return (
    <section>
      <div className="flex items-center gap-2 mb-2">
        <span className={`h-2.5 w-2.5 rounded-full border border-ink ${bgClass(accent)}`} />
        <h3 className="font-display font-bold text-ink">{title}</h3>
        <span className="text-xs font-bold text-ink/40">{entries.length}</span>
      </div>
      {subtitle && <p className="text-xs text-ink/50 mb-3">{subtitle}</p>}
      <div className="grid grid-cols-2 gap-3">
        {entries.map(({ item, amountNeeded, canBuyNow, weeksNeeded }) => (
          <WishlistCard
            key={item.id}
            item={item}
            categories={categories}
            crumbBalance={crumbBalance}
            amountNeeded={amountNeeded}
            canBuyNow={canBuyNow}
            weeksNeeded={weeksNeeded}
            onClick={() => onSelectItem(item)}
          />
        ))}
      </div>
    </section>
  )
}

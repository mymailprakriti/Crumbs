import { useEffect, useState } from 'react'
import { X, Trash2, Check, Plus } from 'lucide-react'
import { Button, SheetHandle, bgClass, ACCENTS } from './primitives'
import { newId } from '../utils/id'

// `focusId`, when set, jumps straight into editing that category as soon
// as the sheet opens — used when it's opened via a press-and-hold on a
// folder tile in Wishlist.jsx, so name/color/delete are all one gesture
// away instead of needing a separate tap to start editing first.
export default function CategoryManagerModal({ open, onClose, categories, onAdd, onRename, onRecolor, onDelete, focusId }) {
  const [editingId, setEditingId] = useState(null)
  const [draftName, setDraftName] = useState('')
  const [newName, setNewName] = useState('')
  const [newColor, setNewColor] = useState('yellow')

  useEffect(() => {
    if (open && focusId) {
      const cat = categories.find((c) => c.id === focusId)
      if (cat) {
        setEditingId(cat.id)
        setDraftName(cat.name)
      }
    }
    if (!open) setEditingId(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, focusId])

  if (!open) return null

  function startEdit(cat) {
    setEditingId(cat.id)
    setDraftName(cat.name)
  }

  function commitEdit() {
    const trimmed = draftName.trim()
    if (trimmed) onRename(editingId, trimmed)
    setEditingId(null)
  }

  function handleAdd() {
    const trimmed = newName.trim()
    if (!trimmed) return
    onAdd({ id: newId('cat'), name: trimmed, color: newColor })
    setNewName('')
    setNewColor('yellow')
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <span className="w-6" />
          <p className="font-display font-bold text-sm text-ink/60">Manage categories</p>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-1 flex flex-col gap-2">
          {categories.map((cat) => (
            <div key={cat.id} className="rounded-chunky-sm border-2 border-ink bg-paper px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span className={`h-6 w-6 shrink-0 rounded-full border-2 border-ink ${bgClass(cat.color)}`} />
                {editingId === cat.id ? (
                  <input
                    autoFocus
                    value={draftName}
                    onChange={(e) => setDraftName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && commitEdit()}
                    className="min-w-0 flex-1 rounded-chunky-sm border-2 border-ink bg-cream px-2 py-1 text-sm font-bold outline-none"
                  />
                ) : (
                  <button className="min-w-0 flex-1 text-left font-bold text-sm truncate" onClick={() => startEdit(cat)}>
                    {cat.name}
                  </button>
                )}

                <div className="flex items-center gap-1 shrink-0">
                  {editingId === cat.id && (
                    <button
                      onClick={commitEdit}
                      className="flex h-7 w-7 items-center justify-center rounded-chunky-sm border-2 border-ink bg-green"
                    >
                      <Check size={13} strokeWidth={2.8} />
                    </button>
                  )}
                  {categories.length > 1 && (
                    <button
                      onClick={() => onDelete(cat.id)}
                      className="flex h-7 w-7 items-center justify-center rounded-chunky-sm border-2 border-ink bg-paper"
                    >
                      <Trash2 size={13} strokeWidth={2.4} className="text-coral-dark" />
                    </button>
                  )}
                </div>
              </div>

              {editingId === cat.id && (
                <div className="flex items-center gap-2 mt-2.5 pl-8">
                  {ACCENTS.map((c) => (
                    <button
                      key={c}
                      onClick={() => onRecolor(cat.id, c)}
                      className={`h-6 w-6 rounded-full border-2 border-ink ${bgClass(c)} ${
                        cat.color === c ? 'ring-2 ring-ink ring-offset-2 ring-offset-cream' : ''
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>
          ))}

          <div className="mt-2 rounded-chunky-md border-[3px] border-ink border-dashed bg-paper/60 p-3 flex flex-col gap-2.5">
            <p className="text-xs font-bold text-ink/50">Add a category</p>
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Books"
              className="w-full rounded-chunky-sm border-2 border-ink bg-paper px-3 py-2 text-sm font-bold outline-none"
            />
            <div className="flex items-center gap-2">
              {ACCENTS.map((c) => (
                <button
                  key={c}
                  onClick={() => setNewColor(c)}
                  className={`h-7 w-7 rounded-full border-2 border-ink ${bgClass(c)} ${
                    newColor === c ? 'ring-2 ring-ink ring-offset-2 ring-offset-cream' : ''
                  }`}
                />
              ))}
            </div>
            <Button accent="yellow" size="sm" disabled={!newName.trim()} onClick={handleAdd}>
              <Plus size={14} strokeWidth={2.6} /> Add category
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

import Coin from './Coin'

// A mason jar that fills up with a pile of coins — used for the crumb
// savings target. `pct` (0–100) controls how many coin rows are stacked;
// the pile is clipped to the jar's body silhouette so it reads as "the
// jar filling up," not a generic progress bar. Bump `pulseKey` (e.g. once
// per crumb deposit) for a coin to drop through the lid slot with a
// couple of motion dashes. Colors are pulled from the current theme's CSS
// custom properties via inline `style`, so the jar re-colors with the
// rest of the app when the theme changes.
export default function CrumbJarGauge({ pct = 0, size = 160, className = '', pulseKey = 0 }) {
  const clamped = Math.max(0, Math.min(100, pct))
  const bodyX = 48
  const bodyY = 56
  const bodyW = 104
  const bodyH = 130
  const bodyR = 20
  const fillH = (bodyH * clamped) / 100
  const clipId = 'jarClip'
  const celebrating = pulseKey > 0
  const ink = 'var(--color-ink)'
  const paper = 'var(--color-paper)'
  const coinFill = 'var(--color-yellow)'
  const coinFillAlt = 'var(--color-yellow-dark)'

  // Stack small coin circles from the jar's floor up to the current fill
  // height instead of a solid liquid rect — rows alternate their column
  // offset and get a tiny deterministic sine jitter so the pile reads as
  // loose coins rather than a perfect grid.
  const coinR = 10
  const rowH = 14
  const cols = 3
  const colSpacing = bodyW / cols
  const rows = Math.max(0, Math.ceil(fillH / rowH))
  const coins = []
  for (let r = 0; r < rows; r++) {
    const y = bodyY + bodyH - coinR - r * rowH
    if (y < bodyY + coinR * 0.4) continue // don't poke out the top of the jar
    const rowCols = r % 2 === 0 ? cols : cols - 1
    const rowOffset = r % 2 === 0 ? 0 : colSpacing / 2
    for (let c = 0; c < rowCols; c++) {
      const jitter = Math.sin(r * 2.3 + c * 1.7) * 3
      const x = bodyX + colSpacing / 2 + rowOffset + c * colSpacing + jitter
      coins.push({ x, y, alt: (r + c) % 2 === 0 })
    }
  }

  return (
    <svg viewBox="0 0 200 220" width={size} height={(size * 220) / 200} className={className}>
      <defs>
        <clipPath id={clipId}>
          <rect x={bodyX} y={bodyY} width={bodyW} height={bodyH} rx={bodyR} />
        </clipPath>
      </defs>

      {/* grounding shadow */}
      <ellipse cx="100" cy="204" rx="46" ry="7" style={{ fill: ink }} opacity="0.08" />

      {/* lid */}
      <rect x="62" y="26" width="76" height="26" rx="8" style={{ fill: coinFill }} stroke={ink} strokeWidth="5" />
      <line x1="72" y1="34" x2="128" y2="34" style={{ stroke: ink }} strokeWidth="2.5" strokeLinecap="round" opacity="0.35" />
      <line x1="72" y1="41" x2="128" y2="41" style={{ stroke: ink }} strokeWidth="2.5" strokeLinecap="round" opacity="0.35" />
      {/* coin slot */}
      <rect x="86" y="31" width="28" height="7" rx="3.5" style={{ fill: ink }} opacity="0.85" />

      {/* neck connecting lid to body */}
      <path d="M 70 48 L 66 60 L 134 60 L 130 48 Z" style={{ fill: paper }} stroke={ink} strokeWidth="5" strokeLinejoin="round" />

      {/* body + clipped coin pile */}
      <g>
        <rect x={bodyX} y={bodyY} width={bodyW} height={bodyH} rx={bodyR} style={{ fill: paper }} />
        <g clipPath={`url(#${clipId})`}>
          {coins.map((coin, i) => (
            <g key={i} transform={`translate(${coin.x}, ${coin.y})`}>
              <circle r={coinR} style={{ fill: coin.alt ? coinFillAlt : coinFill }} stroke={ink} strokeWidth="2.25" />
              <circle
                r={coinR - 3.5}
                fill="none"
                style={{ stroke: coin.alt ? coinFill : coinFillAlt }}
                strokeWidth="1.5"
                opacity="0.6"
              />
            </g>
          ))}
        </g>
        <rect x={bodyX} y={bodyY} width={bodyW} height={bodyH} rx={bodyR} fill="none" stroke={ink} strokeWidth="5" />
      </g>

      {/* glass shine */}
      <path
        d="M 62 78 Q 58 130 66 172"
        fill="none"
        style={{ stroke: paper }}
        strokeWidth="6"
        strokeLinecap="round"
        opacity="0.6"
      />

      {/* a coin dropping through the lid slot, with two motion dashes, on
          each pulseKey bump (i.e. each time a crumb is added) */}
      {celebrating && (
        <g key={`coin-${pulseKey}`}>
          <line
            x1="82"
            y1="2"
            x2="82"
            y2="14"
            style={{ stroke: ink }}
            strokeWidth="3.5"
            strokeLinecap="round"
            className="animate-piggy-dash-fade"
          />
          <line
            x1="118"
            y1="6"
            x2="118"
            y2="18"
            style={{ stroke: ink, animationDelay: '70ms' }}
            strokeWidth="3.5"
            strokeLinecap="round"
            className="animate-piggy-dash-fade"
          />
          <g transform="translate(85, 8)" className="animate-piggy-coin-in">
            <Coin achieved size={30} />
          </g>
        </g>
      )}
    </svg>
  )
}

import { Card } from './primitives'

// The chunky "big number / small label" stat card used across the
// dashboard: Crumb Jar, Money Protected, Safe to Spend, Next Unlock, etc.
export default function DashboardCard({
  label,
  value,
  sublabel,
  accent = 'yellow',
  icon: Icon,
  visual,
  size = 'md', // 'lg' spans full width, 'md' sits in a 2-col grid
  layout = 'col', // 'row' keeps everything on one line so a tall `visual` doesn't stretch the card
  onClick,
  action,
}) {
  const As = onClick ? 'button' : 'div'

  if (layout === 'row') {
    // Deliberately mirrors the col-layout branch's exact structure below
    // (same p-4, same items-start header row, same mt-2 items-end value
    // row, same mt-3 action slot) so this card's height is computed the
    // same way and comes out identical to a sibling 'md' card's — the
    // `visual` is pulled out of flow as an absolute top-right overlay
    // instead of an inline flex sibling, so it can't add extra height.
    return (
      <Card
        as={As}
        accent={accent}
        onClick={onClick}
        className={`relative text-left p-4 flex flex-col justify-between ${size === 'lg' ? 'col-span-2' : ''} ${
          onClick ? 'active:translate-x-[2px] active:translate-y-[2px] active:shadow-none' : ''
        }`}
      >
        <div className="min-h-7 flex items-start justify-between pr-20">
          <span className="text-xs font-bold uppercase tracking-wide text-ink/70">{label}</span>
          {Icon && (
            <span className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-ink bg-paper/35">
              <Icon size={14} strokeWidth={2.6} className="text-ink" />
            </span>
          )}
        </div>
        <div className="mt-2 flex items-end justify-between gap-3 pr-20">
          <div className="min-w-0">
            <p className="text-2xl font-bold text-ink leading-tight break-words">{value}</p>
            {sublabel && <p className="text-xs font-medium text-ink/70 mt-1">{sublabel}</p>}
          </div>
        </div>
        {action && <div className="mt-3 pr-20">{action}</div>}
        {visual && (
          <div className="absolute top-4 right-4 shrink-0 rounded-chunky-md border-2 border-ink bg-paper/90 p-1">
            {visual}
          </div>
        )}
      </Card>
    )
  }

  return (
    <Card
      as={As}
      accent={accent}
      onClick={onClick}
      className={`text-left p-4 flex flex-col justify-between ${size === 'lg' ? 'col-span-2' : ''} ${
        onClick ? 'active:translate-x-[2px] active:translate-y-[2px] active:shadow-none' : ''
      }`}
    >
      <div className="min-h-7 flex items-start justify-between">
        <span className="text-xs font-bold uppercase tracking-wide text-ink/70">{label}</span>
        {Icon && (
          <span className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-ink bg-paper/35">
            <Icon size={14} strokeWidth={2.6} className="text-ink" />
          </span>
        )}
      </div>
      <div className="mt-2 flex items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="text-2xl font-bold text-ink leading-tight break-words">{value}</p>
          {sublabel && <p className="text-xs font-medium text-ink/70 mt-1">{sublabel}</p>}
        </div>
        {visual && (
          <div className="shrink-0 rounded-chunky-md border-2 border-ink bg-paper/90 p-1">{visual}</div>
        )}
      </div>
      {action && <div className="mt-3">{action}</div>}
    </Card>
  )
}

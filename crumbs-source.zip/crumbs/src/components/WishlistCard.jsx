import { Card, bgClass } from './primitives'
import ProgressBar from './ProgressBar'
import { formatCurrency } from '../utils/currency'
import { priorityColor, priorityLabel } from '../theme'
import { getCategoryColor } from '../utils/categories'
import { Check, Clock3, Gift } from 'lucide-react'

// Framed "photo card" — the product photo sits inset with breathing room
// from the outer card border (like a little polaroid), with the name,
// category and price living below it rather than overlaid on the image.
// A small status badge (ready / countdown) overlaps the seam between the
// photo and the info panel. Used in the Wishlist folder view and Planner.
export default function WishlistCard({ item, categories, crumbBalance, weeksNeeded, amountNeeded, canBuyNow, onClick }) {
  const accent = getCategoryColor(categories, item.category)

  return (
    <Card
      as="button"
      onClick={onClick}
      className="w-full text-left p-2 flex flex-col gap-2 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
    >
      <div className="relative">
        <div className="relative aspect-[2/1] w-full overflow-hidden rounded-chunky-sm border-2 border-ink/15">
          {item.image ? (
            <img src={item.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
          ) : (
            <div className={`absolute inset-0 flex items-center justify-center ${bgClass(accent)}`}>
              <Gift size={26} strokeWidth={1.6} className="text-ink/40" />
            </div>
          )}
          <span
            className={`absolute top-1.5 left-1.5 h-2.5 w-2.5 rounded-full border-2 border-ink ${bgClass(
              priorityColor[item.priority]
            )}`}
          />
        </div>

        <span
          className={`absolute bottom-0 right-2 flex h-7 w-7 translate-y-1/2 items-center justify-center rounded-chunky-sm border-2 border-ink ${
            canBuyNow ? 'bg-green' : 'bg-paper'
          }`}
        >
          {canBuyNow ? (
            <Check size={13} strokeWidth={3} className="text-ink" />
          ) : (
            <Clock3 size={12} strokeWidth={2.4} className="text-ink/60" />
          )}
        </span>
      </div>

      <div className="flex flex-col gap-1 px-0.5 pb-0.5">
        <div className="pr-7 flex items-start justify-between gap-1.5">
          <div className="min-w-0">
            <p className="font-bold text-ink truncate leading-tight">{item.name}</p>
            <p className="text-xs text-ink/50 truncate">
              {item.category} · {formatCurrency(item.price)}
            </p>
          </div>
          <span
            title={priorityLabel[item.priority]}
            className={`mt-0.5 h-2.5 w-2.5 shrink-0 rounded-full border-2 border-ink ${bgClass(
              priorityColor[item.priority]
            )}`}
          />
        </div>
        <ProgressBar value={Math.min(item.price, crumbBalance)} max={item.price} accent={accent} />
        <div className="flex items-center justify-between text-xs">
          {canBuyNow ? (
            <span className="font-bold text-green-dark">Guilt-free buy</span>
          ) : (
            <span className="font-bold text-ink/80">Need {formatCurrency(amountNeeded)} more</span>
          )}
          <span className="text-ink/50 font-medium">
            {canBuyNow
              ? 'Ready now'
              : weeksNeeded == null
              ? 'Set a saving rate'
              : weeksNeeded === 0
              ? 'This week'
              : `~${weeksNeeded} wk${weeksNeeded > 1 ? 's' : ''}`}
          </span>
        </div>
      </div>
    </Card>
  )
}

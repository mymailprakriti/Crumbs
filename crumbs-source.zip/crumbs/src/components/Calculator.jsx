import { useState } from 'react'
import { Card, bgClass } from './primitives'
import { Calculator as CalculatorIcon, Delete } from 'lucide-react'

// A plain 4-function calculator for quick napkin math (adding up a
// shopping list, splitting a bill, etc) — separate from "Can I buy this?",
// which checks affordability against your crumb balance specifically.
const OPS = {
  '÷': (a, b) => (b === 0 ? NaN : a / b),
  '×': (a, b) => a * b,
  '−': (a, b) => a - b,
  '+': (a, b) => a + b,
}

function formatResult(n) {
  if (Number.isNaN(n)) return 'Error'
  return String(Math.round(n * 1e8) / 1e8)
}

export default function Calculator() {
  const [display, setDisplay] = useState('0')
  const [stored, setStored] = useState(null)
  const [operator, setOperator] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  function inputDigit(d) {
    if (waitingForOperand) {
      setDisplay(d)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? d : display + d)
    }
  }

  function inputDot() {
    if (waitingForOperand) {
      setDisplay('0.')
      setWaitingForOperand(false)
      return
    }
    if (!display.includes('.')) setDisplay(display + '.')
  }

  function clear() {
    setDisplay('0')
    setStored(null)
    setOperator(null)
    setWaitingForOperand(false)
  }

  function backspace() {
    if (waitingForOperand) return
    setDisplay(display.length > 1 ? display.slice(0, -1) : '0')
  }

  function toggleSign() {
    if (display === '0') return
    setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display)
  }

  function percent() {
    setDisplay(formatResult(parseFloat(display) / 100))
  }

  function chooseOperator(nextOp) {
    const inputValue = parseFloat(display)
    if (stored == null) {
      setStored(inputValue)
    } else if (operator && !waitingForOperand) {
      const result = OPS[operator](stored, inputValue)
      setStored(result)
      setDisplay(formatResult(result))
    }
    setWaitingForOperand(true)
    setOperator(nextOp)
  }

  function equals() {
    if (operator == null || stored == null) return
    const inputValue = parseFloat(display)
    const result = OPS[operator](stored, inputValue)
    setDisplay(formatResult(result))
    setStored(null)
    setOperator(null)
    setWaitingForOperand(true)
  }

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <CalculatorIcon size={16} strokeWidth={2.6} />
        <p className="font-display font-bold">Calculator</p>
      </div>

      <div className="rounded-chunky-sm border-[3px] border-ink bg-cream px-4 py-3 mb-3 text-right overflow-hidden">
        <p className="text-2xl font-bold text-ink truncate">{display}</p>
      </div>

      <div className="grid grid-cols-4 gap-2">
        <CalcButton label="C" accent="coral" onClick={clear} />
        <CalcButton label={<Delete size={16} strokeWidth={2.4} className="mx-auto" />} onClick={backspace} />
        <CalcButton label="%" onClick={percent} />
        <CalcButton label="÷" accent="yellow" active={operator === '÷' && waitingForOperand} onClick={() => chooseOperator('÷')} />

        <CalcButton label="7" onClick={() => inputDigit('7')} />
        <CalcButton label="8" onClick={() => inputDigit('8')} />
        <CalcButton label="9" onClick={() => inputDigit('9')} />
        <CalcButton label="×" accent="yellow" active={operator === '×' && waitingForOperand} onClick={() => chooseOperator('×')} />

        <CalcButton label="4" onClick={() => inputDigit('4')} />
        <CalcButton label="5" onClick={() => inputDigit('5')} />
        <CalcButton label="6" onClick={() => inputDigit('6')} />
        <CalcButton label="−" accent="yellow" active={operator === '−' && waitingForOperand} onClick={() => chooseOperator('−')} />

        <CalcButton label="1" onClick={() => inputDigit('1')} />
        <CalcButton label="2" onClick={() => inputDigit('2')} />
        <CalcButton label="3" onClick={() => inputDigit('3')} />
        <CalcButton label="+" accent="yellow" active={operator === '+' && waitingForOperand} onClick={() => chooseOperator('+')} />

        <CalcButton label="±" onClick={toggleSign} />
        <CalcButton label="0" onClick={() => inputDigit('0')} />
        <CalcButton label="." onClick={inputDot} />
        <CalcButton label="=" accent="green" onClick={equals} />
      </div>
    </Card>
  )
}

function CalcButton({ label, accent, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-chunky-sm border-2 border-ink py-2.5 text-base font-bold transition-transform ${
        accent ? bgClass(accent) : 'bg-paper'
      } ${
        active
          ? 'translate-x-[1px] translate-y-[1px] shadow-none'
          : 'shadow-sticker-sm active:translate-x-[1px] active:translate-y-[1px]'
      }`}
    >
      {label}
    </button>
  )
}

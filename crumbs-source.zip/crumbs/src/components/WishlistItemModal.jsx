import { useEffect, useRef, useState } from 'react'
import { X, Camera, Trash2, Loader2, Settings2 } from 'lucide-react'
import { Button, SheetHandle } from './primitives'
import { resizeImageFile } from '../utils/image'

const blank = {
  name: '',
  price: '',
  category: 'Other',
  priority: 'medium',
  link: '',
  notes: '',
  targetDate: '',
  image: '',
}

export default function WishlistItemModal({ open, onClose, onSave, initial, categories, onOpenCategoryManager }) {
  const [form, setForm] = useState(blank)
  const [photoBusy, setPhotoBusy] = useState(false)
  const [photoError, setPhotoError] = useState('')
  const fileInputRef = useRef(null)

  useEffect(() => {
    if (open) {
      setForm(
        initial
          ? { ...blank, ...initial, price: String(initial.price ?? '') }
          : { ...blank, category: categories?.[0]?.name || 'Other' }
      )
    }
    setPhotoError('')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initial])

  if (!open) return null

  function set(key, value) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  async function handlePhotoChange(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setPhotoError('That file isn’t an image.')
      return
    }
    setPhotoBusy(true)
    setPhotoError('')
    try {
      const dataUrl = await resizeImageFile(file)
      set('image', dataUrl)
    } catch (err) {
      setPhotoError('Could not use that photo — try a different one.')
    } finally {
      setPhotoBusy(false)
    }
  }

  function submit() {
    if (!form.name.trim() || !(Number(form.price) > 0)) return
    onSave({ ...form, price: Number(form.price) })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <span className="w-6" />
          <p className="font-display font-bold text-sm text-ink/60">
            {initial ? 'Edit wishlist item' : 'Add to wishlist'}
          </p>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-2 flex flex-col gap-3">
          <Field label="Photo (optional)">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="relative h-20 w-20 shrink-0 overflow-hidden rounded-chunky-sm border-[3px] border-ink bg-paper flex items-center justify-center"
              >
                {photoBusy ? (
                  <Loader2 size={20} className="animate-spin text-ink/50" />
                ) : form.image ? (
                  <img src={form.image} alt="" className="h-full w-full object-cover" />
                ) : (
                  <Camera size={20} strokeWidth={2.2} className="text-ink/40" />
                )}
              </button>
              <div className="flex flex-col gap-1.5">
                <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                  {form.image ? 'Change photo' : 'Add photo'}
                </Button>
                {form.image && (
                  <button
                    type="button"
                    onClick={() => set('image', '')}
                    className="inline-flex items-center gap-1 text-xs font-bold text-coral-dark"
                  >
                    <Trash2 size={12} strokeWidth={2.4} /> Remove
                  </button>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                hidden
                onChange={handlePhotoChange}
              />
            </div>
            {photoError && <p className="text-xs text-coral-dark mt-1">{photoError}</p>}
          </Field>

          <Field label="What do you want?">
            <input
              autoFocus
              type="text"
              placeholder="e.g. Sony Headphones"
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
              className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-4 py-3 font-bold outline-none"
            />
          </Field>

          <Field label="Price">
            <input
              type="number"
              inputMode="decimal"
              placeholder="₹0"
              value={form.price}
              onChange={(e) => set('price', e.target.value)}
              className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-4 py-3 text-xl font-bold outline-none"
            />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Category"
              action={
                <button type="button" onClick={onOpenCategoryManager} className="inline-flex items-center gap-0.5 text-[11px] font-bold text-blue-dark">
                  <Settings2 size={11} strokeWidth={2.6} /> Manage
                </button>
              }
            >
              <select
                value={form.category}
                onChange={(e) => set('category', e.target.value)}
                className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-3 py-3 font-bold outline-none"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Priority">
              <select
                value={form.priority}
                onChange={(e) => set('priority', e.target.value)}
                className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-3 py-3 font-bold outline-none"
              >
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </Field>
          </div>

          <Field label="Link (optional)">
            <input
              type="text"
              placeholder="https://..."
              value={form.link}
              onChange={(e) => set('link', e.target.value)}
              className="w-full rounded-chunky-sm border-2 border-ink/30 bg-paper px-4 py-2.5 text-sm outline-none"
            />
          </Field>

          <Field label="Notes (optional)">
            <input
              type="text"
              placeholder="Anything to remember"
              value={form.notes}
              onChange={(e) => set('notes', e.target.value)}
              className="w-full rounded-chunky-sm border-2 border-ink/30 bg-paper px-4 py-2.5 text-sm outline-none"
            />
          </Field>

          <Button
            accent="yellow"
            size="lg"
            className="w-full mt-2"
            disabled={!form.name.trim() || !(Number(form.price) > 0)}
            onClick={submit}
          >
            {initial ? 'Save changes' : 'Add to wishlist'}
          </Button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children, action }) {
  return (
    <label className="block">
      <span className="flex items-center justify-between mb-1">
        <span className="block text-xs font-bold text-ink/50">{label}</span>
        {action}
      </span>
      {children}
    </label>
  )
}

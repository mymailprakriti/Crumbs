import { useMemo, useState } from 'react'
import { Card } from './primitives'
import { getStaleWish } from '../utils/wishes'
import Coin from './Coin'

// Compact Dashboard entry point for the Wishing Well — a wishes + habit
// tracker that sits next to (but separate from) the crumb ledger. Add a
// free-form wish ("start eating healthier"), watch a coin get tossed in,
// and get nudged if one's gone quiet for a week. No checklist here — that
// lives in WishingWellSheet — just the add form and the one nudge that
// actually needs your attention, so the Dashboard stays short.
export default function WishingWellCard({ wishes, onAdd, onTouch, onSetStatus, onOpenSheet }) {
  const [text, setText] = useState('')
  const [tossing, setTossing] = useState(false)
  const [tossKey, setTossKey] = useState(0)

  const staleWish = useMemo(() => getStaleWish(wishes), [wishes])

  function handleAdd() {
    const trimmed = text.trim()
    if (!trimmed) return
    onAdd(trimmed)
    setText('')
    setTossKey((k) => k + 1)
    setTossing(true)
    setTimeout(() => setTossing(false), 750)
  }

  return (
    <Card className="p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-bold text-ink">Wishing Well</h3>
        <button onClick={onOpenSheet} className="text-xs font-bold text-ink/40">
          {wishes.length} coin{wishes.length === 1 ? '' : 's'} · See all
        </button>
      </div>

      <div className="flex items-center gap-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          placeholder="A wish, big or small…"
          className="min-w-0 flex-1 rounded-chunky-sm border-2 border-ink/25 bg-paper px-3 py-2.5 text-sm font-medium outline-none"
        />
        <button
          onClick={handleAdd}
          disabled={!text.trim()}
          className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border-[3px] border-ink bg-ink disabled:opacity-40"
        >
          <Coin key={tossKey} size={22} className={tossing ? 'animate-coin-spin-drop' : ''} />
        </button>
      </div>

      {staleWish && (
        <div className="rounded-chunky-sm border-2 border-ink bg-yellow px-3.5 py-3">
          <p className="text-sm font-bold text-ink mb-2.5 leading-snug">
            Your “{staleWish.text}” coin is pending — how's it going?
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => onSetStatus(staleWish.id, 'achieved')}
              className="flex-1 rounded-chunky-sm border-2 border-ink bg-green px-2 py-2 text-xs font-bold active:translate-x-[1px] active:translate-y-[1px]"
            >
              Did it 🎉
            </button>
            <button
              onClick={() => onTouch(staleWish.id)}
              className="flex-1 rounded-chunky-sm border-2 border-ink bg-paper px-2 py-2 text-xs font-bold active:translate-x-[1px] active:translate-y-[1px]"
            >
              Still working on it
            </button>
          </div>
        </div>
      )}
    </Card>
  )
}

// Illustrated Wishing Well coin — chunky ink outline, gold when pending,
// green when achieved, an embossed inner ring and a rupee mark, matching
// the app's sticker-illustration language instead of a plain emoji.
// Colors are pulled from the CSS custom properties the current theme sets
// (see utils/applyTheme.js), via inline `style` rather than raw SVG
// attributes — presentation attributes don't reliably resolve var(), but
// inline CSS always does — so the coin re-colors along with everything
// else when the theme changes.
export default function Coin({ achieved = false, size = 32, className = '' }) {
  const fill = achieved ? 'var(--color-green)' : 'var(--color-yellow)'
  const ring = achieved ? 'var(--color-green-dark)' : 'var(--color-yellow-dark)'

  return (
    <svg viewBox="0 0 40 40" width={size} height={size} className={className}>
      <circle cx="20" cy="20" r="17.5" style={{ fill }} stroke="var(--color-ink)" strokeWidth="3" />
      <circle cx="20" cy="20" r="12" fill="none" style={{ stroke: ring }} strokeWidth="2.25" />
      <text
        x="20"
        y="26"
        textAnchor="middle"
        fontSize="15"
        fontWeight="800"
        style={{ fill: 'var(--color-ink)' }}
        fontFamily="Manrope, ui-sans-serif, system-ui, sans-serif"
      >
        ₹
      </text>
    </svg>
  )
}

import { useMemo, useState } from 'react'
import { X, Pencil } from 'lucide-react'
import { SheetHandle, bgClass } from './primitives'
import { getCrumbBreakdown } from '../utils/calculations'
import { formatCurrency } from '../utils/currency'
import { sourceColor, sourceLabel } from '../theme'
import { startOfMonthKey } from '../utils/week'
import CrumbJarGauge from './CrumbJarGauge'

// Opened by tapping the Crumb Jar card on the Dashboard. Leads with a
// piggy-bank fill gauge against your savings target, then a bar-chart
// breakdown of every crumb deposit grouped by where it came from (skipped
// food, refund, cashback, manual add, ...) so the answer to "where am I
// actually getting crumbs from?" is visual, not just a number.
export default function CrumbBreakdownSheet({ open, transactions, crumbBalance, settings, onUpdateSettings, onClose, depositPulse }) {
  const [range, setRange] = useState('month') // 'month' | 'all'
  const [editingTarget, setEditingTarget] = useState(false)
  const [targetDraft, setTargetDraft] = useState('')

  const monthKey = range === 'month' ? startOfMonthKey() : undefined
  const { total, rows } = useMemo(
    () => getCrumbBreakdown(transactions, { monthKey }),
    [transactions, monthKey]
  )

  if (!open) return null

  const target = settings.crumbSavingTarget || 0
  const pct = target > 0 ? Math.min(100, (crumbBalance / target) * 100) : 0

  function startEditTarget() {
    setTargetDraft(target > 0 ? String(target) : '')
    setEditingTarget(true)
  }

  function commitTarget() {
    const val = Math.max(0, Math.round(Number(targetDraft) || 0))
    onUpdateSettings({ crumbSavingTarget: val })
    setEditingTarget(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <span className="w-6" />
          <p className="font-display font-bold text-sm text-ink/60">Crumb breakdown</p>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="flex flex-col items-center px-5 pb-5 pt-1">
          <CrumbJarGauge pct={pct} size={192} pulseKey={depositPulse} />
          <p className="mt-1 text-2xl font-bold text-ink">
            {formatCurrency(crumbBalance)}
            <span className="text-sm font-bold text-ink/40"> / {target > 0 ? formatCurrency(target) : '—'}</span>
          </p>
          {editingTarget ? (
            <div className="flex items-center gap-2 mt-2.5">
              <input
                autoFocus
                type="number"
                inputMode="decimal"
                value={targetDraft}
                onChange={(e) => setTargetDraft(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && commitTarget()}
                placeholder="Savings target"
                className="w-32 rounded-chunky-sm border-2 border-ink bg-paper px-3 py-1.5 text-sm font-bold text-center outline-none"
              />
              <button
                onClick={commitTarget}
                className="rounded-chunky-sm border-2 border-ink bg-green px-3 py-1.5 text-xs font-bold"
              >
                Save
              </button>
            </div>
          ) : (
            <button
              onClick={startEditTarget}
              className="mt-2 flex items-center gap-1 text-xs font-bold text-ink/40"
            >
              <Pencil size={11} strokeWidth={2.4} />
              {target > 0 ? 'Edit target' : 'Set a savings target'}
            </button>
          )}
        </div>

        <div className="px-5 pb-8 pt-2 border-t-2 border-ink/10">
          <div className="flex gap-2 mb-5">
            <RangeButton active={range === 'month'} onClick={() => setRange('month')}>
              This month
            </RangeButton>
            <RangeButton active={range === 'all'} onClick={() => setRange('all')}>
              All time
            </RangeButton>
          </div>

          <p className="text-xs font-bold text-ink/50 mb-0.5">
            Total crumbs {range === 'month' ? 'this month' : 'ever'}
          </p>
          <p className="text-3xl font-bold mb-6">{formatCurrency(total)}</p>

          {rows.length === 0 ? (
            <p className="text-sm text-ink/50 py-6 text-center">
              No crumbs {range === 'month' ? 'this month yet' : 'yet'}.
            </p>
          ) : (
            <div className="flex flex-col gap-4">
              {rows.map((row) => (
                <div key={row.source}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-bold truncate pr-2">{sourceLabel[row.source] || row.source}</span>
                    <span className="text-sm font-bold text-ink/60 shrink-0">
                      {formatCurrency(row.amount)} · {row.pct}%
                    </span>
                  </div>
                  <div className="h-4 w-full rounded-full border-2 border-ink bg-paper overflow-hidden">
                    <div
                      className={`h-full ${bgClass(sourceColor[row.source] || 'yellow')}`}
                      style={{ width: `${row.pct > 0 ? Math.max(row.pct, 3) : 0}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function RangeButton({ active, children, ...rest }) {
  return (
    <button
      className={`flex-1 rounded-chunky-sm border-[3px] border-ink px-3 py-2 text-sm font-bold transition-transform ${
        active ? 'bg-yellow translate-x-[2px] translate-y-[2px] shadow-none' : 'bg-paper shadow-sticker-sm'
      }`}
      {...rest}
    >
      {children}
    </button>
  )
}

import { useRef } from 'react'
import CategoryFolderCard from './CategoryFolderCard'

// Wraps a CategoryFolderCard with pointer-based interaction: a quick tap
// opens the folder, a press-and-hold opens it for editing (name/color/
// delete), and dragging (move past a small threshold before the long-press
// timer fires) picks the tile up and reorders the grid live as it passes
// over neighbors. All three gestures share one pointer stream so there's
// no separate "edit mode" toggle or reorder buttons to tap first.
const LONG_PRESS_MS = 480
const MOVE_THRESHOLD = 10

export default function FolderTile({
  category,
  count,
  dragId,
  dragPos,
  onOpen,
  onLongPress,
  onDragStart,
  onDragMove,
  onDragEnd,
}) {
  const startRef = useRef(null)
  const timerRef = useRef(null)
  const stateRef = useRef('idle') // 'idle' | 'pending' | 'dragging' | 'longpressed'
  const isDragging = dragId === category.id

  function clearTimer() {
    if (timerRef.current) {
      clearTimeout(timerRef.current)
      timerRef.current = null
    }
  }

  function handlePointerDown(e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return
    startRef.current = { x: e.clientX, y: e.clientY }
    stateRef.current = 'pending'
    e.currentTarget.setPointerCapture?.(e.pointerId)
    timerRef.current = setTimeout(() => {
      if (stateRef.current === 'pending') {
        stateRef.current = 'longpressed'
        onLongPress()
      }
    }, LONG_PRESS_MS)
  }

  function handlePointerMove(e) {
    if (stateRef.current === 'idle' || stateRef.current === 'longpressed' || !startRef.current) return
    const dx = e.clientX - startRef.current.x
    const dy = e.clientY - startRef.current.y
    if (stateRef.current === 'pending' && Math.hypot(dx, dy) > MOVE_THRESHOLD) {
      clearTimer()
      stateRef.current = 'dragging'
      onDragStart(category.id, startRef.current.x, startRef.current.y)
    }
    if (stateRef.current === 'dragging') {
      onDragMove(e.clientX, e.clientY)
    }
  }

  function handlePointerUp() {
    clearTimer()
    if (stateRef.current === 'pending') {
      onOpen()
    } else if (stateRef.current === 'dragging') {
      onDragEnd()
    }
    stateRef.current = 'idle'
    startRef.current = null
  }

  const style = isDragging
    ? { transform: `translate(${dragPos.dx}px, ${dragPos.dy}px) scale(1.05)`, zIndex: 30 }
    : undefined

  return (
    <div
      data-category-id={category.id}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className={`relative touch-none select-none ${isDragging ? 'opacity-90' : 'transition-transform'}`}
      style={style}
    >
      <CategoryFolderCard category={category} count={count} lifted={isDragging} />
    </div>
  )
}

import { bgClass } from './primitives'

export default function ProgressBar({ value, max, accent = 'green', className = '' }) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0
  return (
    <div className={`h-3.5 w-full rounded-chunky-sm border-2 border-ink bg-paper overflow-hidden ${className}`}>
      <div
        className={`h-full ${bgClass(accent)} border-r-2 border-ink transition-[width] duration-500 ease-out`}
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { ACCENTS, bgClass } from './primitives'

// The last tile in the Wishlist folder grid — a ghost "new folder" card.
// The icon well itself is the advance button through all three steps:
// tap it to open the name field, type a name and tap it again to move to
// the color swatches, pick a color and tap it a third time to create the
// folder. Every step keeps the same outer shape (icon well + one content
// row) as the resting CategoryFolderCard beside it, so nothing resizes.
export default function AddCategoryFolderCard({ onAdd }) {
  const [step, setStep] = useState('idle') // 'idle' | 'name' | 'color'
  const [name, setName] = useState('')
  const [color, setColor] = useState(ACCENTS[0])

  function reset() {
    setStep('idle')
    setName('')
    setColor(ACCENTS[0])
  }

  function handlePlus() {
    if (step === 'idle') {
      setStep('name')
    } else if (step === 'name') {
      if (!name.trim()) return
      setStep('color')
    } else if (step === 'color') {
      onAdd(name.trim(), color)
      reset()
    }
  }

  if (step === 'idle') {
    return (
      <button
        onClick={handlePlus}
        className="rounded-chunky-md border-[3px] border-ink border-dashed bg-paper/40 p-3.5 flex flex-col gap-7 items-start text-left active:translate-x-[2px] active:translate-y-[2px]"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-chunky-sm border-2 border-ink bg-paper">
          <Plus size={16} strokeWidth={2.2} />
        </span>
        <p className="font-bold text-ink/60">New folder</p>
      </button>
    )
  }

  return (
    <div className="rounded-chunky-md border-[3px] border-ink border-dashed bg-paper/60 p-3.5 flex flex-col gap-7">
      <button
        onClick={handlePlus}
        disabled={step === 'name' && !name.trim()}
        title={step === 'name' ? 'Next: pick a color' : 'Create folder'}
        className={`flex h-9 w-9 items-center justify-center rounded-chunky-sm border-2 border-ink transition-transform active:scale-90 disabled:opacity-30 ${bgClass(
          step === 'color' ? color : 'paper'
        )}`}
      >
        <Plus size={16} strokeWidth={2.2} />
      </button>

      {step === 'name' && (
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handlePlus()
            if (e.key === 'Escape') reset()
          }}
          placeholder="Folder name"
          className="h-9 w-full min-w-0 rounded-chunky-sm border-2 border-ink bg-paper px-2 text-sm font-bold outline-none"
        />
      )}

      {step === 'color' && (
        <div className="flex h-9 flex-wrap items-center gap-1.5" title={`Pick a color for "${name.trim()}"`}>
          {ACCENTS.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              className={`h-6 w-6 rounded-full border-2 border-ink ${bgClass(c)} transition-transform active:scale-90 ${
                color === c ? 'ring-2 ring-ink ring-offset-1 ring-offset-cream' : ''
              }`}
            />
          ))}
        </div>
      )}
    </div>
  )
}

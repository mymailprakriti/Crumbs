import { useMemo } from 'react'
import { Card, Button } from './primitives'
import ProgressBar from './ProgressBar'
import { formatCurrency } from '../utils/currency'
import { getItemStatus, getBalanceAfterPurchase, getPurchaseImpact } from '../utils/calculations'
import { PartyPopper, Clock3 } from 'lucide-react'

// Used both as the "Can I buy this?" view on a wishlist item, and reused
// inline in the wishlist detail sheet.
export default function PurchaseSimulator({ item, crumbBalance, wishlistItems, weeklyCrumbRate, onConfirmPurchase }) {
  const { amountNeeded, canBuyNow, weeksNeeded } = useMemo(
    () => getItemStatus(item, crumbBalance, weeklyCrumbRate),
    [item, crumbBalance, weeklyCrumbRate]
  )
  const balanceAfter = getBalanceAfterPurchase(crumbBalance, item.price)
  const impact = useMemo(
    () => (canBuyNow ? getPurchaseImpact(item, crumbBalance, wishlistItems, weeklyCrumbRate) : []),
    [item, crumbBalance, wishlistItems, weeklyCrumbRate, canBuyNow]
  )

  return (
    <div className="flex flex-col gap-4">
      {canBuyNow ? (
        <Card accent="green" className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <PartyPopper size={18} strokeWidth={2.4} />
            <p className="font-display font-bold">Yes, you can buy this guilt-free.</p>
          </div>
          <div className="text-sm mt-2 space-y-1 text-ink/80">
            <div className="flex justify-between">
              <span>Price</span>
              <span className="font-bold text-ink">{formatCurrency(item.price)}</span>
            </div>
            <div className="flex justify-between">
              <span>Current crumbs</span>
              <span className="font-bold text-ink">{formatCurrency(crumbBalance)}</span>
            </div>
            <div className="flex justify-between">
              <span>Balance after purchase</span>
              <span className="font-bold text-ink">{formatCurrency(balanceAfter)}</span>
            </div>
          </div>
        </Card>
      ) : (
        <Card accent="yellow" className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Clock3 size={18} strokeWidth={2.4} />
            <p className="font-display font-bold">Not yet — you're close.</p>
          </div>
          <p className="text-sm text-ink/80 mt-2">
            You need <span className="font-bold text-ink">{formatCurrency(amountNeeded)}</span> more.
            {weeksNeeded == null ? (
              <> Add your saving rate in Settings to see an ETA.</>
            ) : (
              <>
                {' '}
                At your current rate, you can buy this in{' '}
                <span className="font-bold text-ink">
                  {weeksNeeded} week{weeksNeeded === 1 ? '' : 's'}
                </span>
                .
              </>
            )}
          </p>
          <ProgressBar value={crumbBalance} max={item.price} accent="yellow" className="mt-3" />
        </Card>
      )}

      {canBuyNow && (
        <Card className="p-4">
          <p className="font-bold text-sm mb-2">Impact on your other wishes</p>
          {impact.length === 0 ? (
            <p className="text-sm text-ink/60">This purchase does not delay any other wishlist item.</p>
          ) : (
            <ul className="space-y-1.5">
              {impact.map((d) => (
                <li key={d.id} className="text-sm text-ink/80">
                  Buying this will delay <span className="font-bold text-ink">{d.name}</span> by {d.delay} week
                  {d.delay > 1 ? 's' : ''}.
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}

      {canBuyNow && (
        <Button accent="green" size="lg" onClick={onConfirmPurchase}>
          Confirm guilt-free buy
        </Button>
      )}
    </div>
  )
}

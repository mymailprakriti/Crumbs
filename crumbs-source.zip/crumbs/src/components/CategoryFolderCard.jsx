import { Gift } from 'lucide-react'
import { bgClass } from './primitives'

// Folder-style entry point into one wishlist category — a colored "tab"
// peeking out above a chunky card, an icon well, the category name and how
// many active items live inside. Purely presentational: FolderTile (which
// wraps this) owns the tap/drag/long-press gestures.
export default function CategoryFolderCard({ category, count, lifted = false }) {
  return (
    <div className="relative">
      <div
        className={`absolute -top-2 left-3 h-4 w-14 rounded-t-md border-[3px] border-b-0 border-ink ${bgClass(
          category.color
        )}`}
      />
      <div
        className={`relative rounded-chunky-md border-[3px] border-ink ${bgClass(category.color)} p-3.5 flex flex-col gap-7 ${
          lifted ? 'shadow-sticker-lg' : 'shadow-sticker-sm'
        }`}
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-chunky-sm border-2 border-ink bg-paper/70">
          <Gift size={16} strokeWidth={2.2} />
        </span>
        <div>
          <p className="font-bold text-ink truncate">{category.name}</p>
          <p className="text-xs text-ink/60 font-medium">
            {count} item{count === 1 ? '' : 's'}
          </p>
        </div>
      </div>
    </div>
  )
}

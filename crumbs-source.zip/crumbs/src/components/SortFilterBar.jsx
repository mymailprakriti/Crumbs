import { useState } from 'react'
import { ArrowUpDown, ChevronDown } from 'lucide-react'
import { bgClass } from './primitives'

const SORT_OPTIONS = [
  { value: 'priority', label: 'Priority' },
  { value: 'price', label: 'Price: low to high' },
  { value: 'newest', label: 'Date added: newest' },
]

// A single "Sort" pill that expands into the option row on tap, instead of
// permanently taking up space — collapses again once you pick one.
export default function SortFilterBar({ value, onChange, accent = 'blue' }) {
  const [open, setOpen] = useState(false)
  const active = SORT_OPTIONS.find((o) => o.value === value)

  return (
    <div>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center gap-1.5 rounded-chunky-sm border-[3px] border-ink px-3 py-1.5 text-xs font-bold transition-transform ${
          open
            ? `${bgClass(accent)} translate-x-[1px] translate-y-[1px] shadow-none`
            : 'bg-paper shadow-sticker-sm active:translate-x-[1px] active:translate-y-[1px]'
        }`}
      >
        <ArrowUpDown size={12} strokeWidth={2.6} />
        {active ? `Sort: ${active.label}` : 'Sort'}
        <ChevronDown size={12} strokeWidth={2.6} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="flex flex-wrap gap-2 mt-2 animate-pop-in">
          {SORT_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => {
                onChange(opt.value)
                setOpen(false)
              }}
              className={`rounded-chunky-sm border-2 border-ink px-2.5 py-1.5 text-xs font-bold transition-transform active:translate-x-[1px] active:translate-y-[1px] ${
                value === opt.value ? bgClass(accent) : 'bg-paper'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

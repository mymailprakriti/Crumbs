// Small internal building blocks shared by the named components the spec
// calls for (DashboardCard, WishlistCard, etc). Not part of the required
// component list itself — just avoids repeating the same Tailwind class
// strings everywhere. Colors are always passed in as an accent key
// ('yellow' | 'green' | 'coral' | 'pink' | 'blue' | 'purple') so restyling
// stays centralized in theme.js / index.css.

export const ACCENTS = ['yellow', 'green', 'coral', 'pink', 'blue', 'purple']

const BG = {
  yellow: 'bg-yellow',
  green: 'bg-green',
  coral: 'bg-coral',
  pink: 'bg-pink',
  blue: 'bg-blue',
  purple: 'bg-purple',
  cream: 'bg-cream',
  paper: 'bg-paper',
}

const BG_DARK = {
  yellow: 'bg-yellow-dark',
  green: 'bg-green-dark',
  coral: 'bg-coral-dark',
  pink: 'bg-pink-dark',
  blue: 'bg-blue-dark',
  purple: 'bg-purple-dark',
}

export function bgClass(accent) {
  return BG[accent] || BG.paper
}

export function bgDarkClass(accent) {
  return BG_DARK[accent] || BG_DARK.yellow
}

export function Card({ as: As = 'div', accent, className = '', children, ...rest }) {
  return (
    <As
      className={`rounded-chunky-md border-[3px] border-ink ${accent ? bgClass(accent) : 'bg-paper'} shadow-sticker-sm ${className}`}
      {...rest}
    >
      {children}
    </As>
  )
}

export function Chip({ children, accent = 'yellow', className = '', active = true }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-chunky-sm border-2 border-ink px-2.5 py-1 text-xs font-bold ${
        active ? bgClass(accent) : 'bg-paper'
      } ${className}`}
    >
      {children}
    </span>
  )
}

export function Button({
  children,
  accent = 'yellow',
  variant = 'solid',
  size = 'md',
  className = '',
  ...rest
}) {
  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2.5 text-sm',
    lg: 'px-5 py-3.5 text-base',
  }
  const base =
    'inline-flex items-center justify-center gap-2 font-bold rounded-chunky-sm border-[3px] border-ink transition-transform active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:opacity-40 disabled:pointer-events-none'
  const variants = {
    // Solid = the primary call-to-action look: the bolder "-dark" accent
    // tone rather than the pastel base, so CTAs read as clearly tappable.
    // No hardcoded text color — the .bg-{accent}-dark pairing rule in
    // index.css picks black or white automatically for legibility.
    solid: `${bgDarkClass(accent)} shadow-sticker-sm`,
    outline: 'bg-paper text-ink shadow-sticker-sm',
    ghost: 'border-transparent shadow-none',
  }
  return (
    <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...rest}>
      {children}
    </button>
  )
}

export function IconButton({ children, className = '', ...rest }) {
  return (
    <button
      className={`inline-flex items-center justify-center h-9 w-9 rounded-chunky-sm border-[3px] border-ink bg-paper shadow-sticker-sm active:translate-x-[2px] active:translate-y-[2px] active:shadow-none ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

export function SheetHandle() {
  return <div className="mx-auto mt-2 h-1.5 w-12 rounded-full bg-ink/20" />
}

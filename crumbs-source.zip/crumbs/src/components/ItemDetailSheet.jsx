import { X, Pencil, Archive, Trash2 } from 'lucide-react'
import { SheetHandle, Chip, IconButton } from './primitives'
import PurchaseSimulator from './PurchaseSimulator'
import { formatCurrency } from '../utils/currency'
import { priorityColor, priorityLabel } from '../theme'

export default function ItemDetailSheet({
  item,
  crumbBalance,
  wishlistItems,
  weeklyCrumbRate,
  onClose,
  onBuy,
  onEdit,
  onArchive,
  onDelete,
}) {
  if (!item) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <div className="flex gap-1.5">
            <IconButton onClick={() => onEdit(item)} aria-label="Edit">
              <Pencil size={15} strokeWidth={2.4} />
            </IconButton>
            <IconButton onClick={() => onArchive(item)} aria-label="Archive">
              <Archive size={15} strokeWidth={2.4} />
            </IconButton>
            <IconButton onClick={() => onDelete(item)} aria-label="Delete">
              <Trash2 size={15} strokeWidth={2.4} />
            </IconButton>
          </div>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-1">
          {item.image && (
            <div className="mb-4 h-48 w-full overflow-hidden rounded-chunky-md border-[3px] border-ink">
              <img src={item.image} alt="" className="h-full w-full object-cover" />
            </div>
          )}
          <div className="flex items-start justify-between gap-2 mb-1">
            <h2 className="font-display text-2xl font-bold leading-tight">{item.name}</h2>
            <Chip accent={priorityColor[item.priority]} className="shrink-0">
              {priorityLabel[item.priority]}
            </Chip>
          </div>
          <p className="text-sm text-ink/60 mb-1">{item.category}</p>
          {item.notes && <p className="text-sm text-ink/60 mb-3">{item.notes}</p>}
          <p className="text-3xl font-bold mb-5">{formatCurrency(item.price)}</p>

          <PurchaseSimulator
            item={item}
            crumbBalance={crumbBalance}
            wishlistItems={wishlistItems}
            weeklyCrumbRate={weeklyCrumbRate}
            onConfirmPurchase={() => onBuy(item)}
          />

          {item.link && (
            <a
              href={item.link}
              target="_blank"
              rel="noreferrer"
              className="block text-center text-sm font-bold text-blue-dark underline underline-offset-2 mt-4"
            >
              View item link
            </a>
          )}
        </div>
      </div>
    </div>
  )
}

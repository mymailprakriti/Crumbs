import { useMemo, useState } from 'react'
import { Card } from './primitives'
import { formatCurrency } from '../utils/currency'
import {
  getAmountNeeded,
  getCanBuyNow,
  getWeeksNeeded,
  getBalanceAfterPurchase,
  getPurchaseImpact,
} from '../utils/calculations'
import { Sparkles } from 'lucide-react'

export default function QuickCalculator({ crumbBalance, weeklyCrumbRate, wishlistItems }) {
  const [price, setPrice] = useState('')
  const numeric = Number(price) || 0

  const result = useMemo(() => {
    if (!numeric) return null
    const amountNeeded = getAmountNeeded(numeric, crumbBalance)
    const canBuyNow = getCanBuyNow(numeric, crumbBalance)
    const weeksNeeded = getWeeksNeeded(amountNeeded, weeklyCrumbRate)
    const balanceAfter = getBalanceAfterPurchase(crumbBalance, numeric)
    const impact = canBuyNow
      ? getPurchaseImpact({ id: '__quick__', price: numeric }, crumbBalance, wishlistItems, weeklyCrumbRate)
      : []
    return { amountNeeded, canBuyNow, weeksNeeded, balanceAfter, impact }
  }, [numeric, crumbBalance, weeklyCrumbRate, wishlistItems])

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={16} strokeWidth={2.6} />
        <p className="font-display font-bold">Can I buy this?</p>
      </div>

      <label className="block text-xs font-bold text-ink/60 mb-1">Item price</label>
      <input
        type="number"
        inputMode="decimal"
        placeholder="e.g. 3999"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        className="w-full rounded-chunky-sm border-[3px] border-ink bg-cream px-3 py-2.5 text-lg font-bold outline-none placeholder:text-ink/30 placeholder:font-normal"
      />

      {result && (
        <div className="mt-3 rounded-chunky-sm border-2 border-ink bg-paper p-3 text-sm">
          {result.canBuyNow ? (
            <>
              <p className="font-bold text-green-dark">Yes, you can buy this.</p>
              <p className="text-ink/70 mt-1">Remaining crumbs: {formatCurrency(result.balanceAfter)}</p>
              {result.impact.length > 0 && (
                <ul className="mt-2 space-y-1 text-ink/70">
                  {result.impact.map((d) => (
                    <li key={d.id}>
                      Delays <span className="font-bold text-ink">{d.name}</span> by {d.delay} wk
                      {d.delay > 1 ? 's' : ''}
                    </li>
                  ))}
                </ul>
              )}
            </>
          ) : (
            <>
              <p className="font-bold text-ink">Not yet.</p>
              <p className="text-ink/70 mt-1">You need {formatCurrency(result.amountNeeded)} more.</p>
              <p className="text-ink/70">
                {result.weeksNeeded == null
                  ? 'Add your saving rate to see an ETA.'
                  : `At your current rate, you can buy this in ${result.weeksNeeded} week${
                      result.weeksNeeded === 1 ? '' : 's'
                    }.`}
              </p>
            </>
          )}
        </div>
      )}
    </Card>
  )
}

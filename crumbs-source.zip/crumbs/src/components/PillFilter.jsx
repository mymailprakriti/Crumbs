import { bgClass } from './primitives'

export default function PillFilter({ options, value, onChange, accent = 'yellow' }) {
  return (
    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 -mx-4 px-4">
      {options.map((opt) => {
        const active = opt.value === value
        return (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            className={`shrink-0 rounded-chunky-sm border-[3px] border-ink px-3.5 py-1.5 text-sm font-bold whitespace-nowrap transition-transform ${
              active
                ? `${bgClass(accent)} translate-x-[2px] translate-y-[2px] shadow-none`
                : 'bg-paper shadow-sticker-sm active:translate-x-[1px] active:translate-y-[1px]'
            }`}
          >
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}

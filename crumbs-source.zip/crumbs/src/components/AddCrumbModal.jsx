import { useState } from 'react'
import { X, ChevronLeft, PiggyBank, Gift as GiftIcon } from 'lucide-react'
import { Button, SheetHandle } from './primitives'
import { formatCurrency } from '../utils/currency'
import { getRewardOptions } from '../utils/calculations'
import { crumbSourceGroups } from '../data/initialData'

const initialDraft = {
  bucket: null, // 'from_budget' | 'outside_budget'
  reasonValue: null,
  reasonLabel: '',
  category: 'Other',
  note: '',
  amount: '',
  rewardPct: null,
  customReward: '',
}

export default function AddCrumbModal({ open, onClose, onSubmit }) {
  const [step, setStep] = useState('bucket')
  const [draft, setDraft] = useState(initialDraft)
  const [lastResult, setLastResult] = useState(null)

  if (!open) return null

  function reset() {
    setStep('bucket')
    setDraft(initialDraft)
    setLastResult(null)
  }

  function handleClose() {
    reset()
    onClose()
  }

  function chooseBucket(bucket) {
    setDraft((d) => ({ ...d, bucket }))
    setStep('reason')
  }

  function chooseReason(opt) {
    setDraft((d) => ({ ...d, reasonValue: opt.value, reasonLabel: opt.label, category: opt.category }))
    setStep('amount')
  }

  function goToNextAfterAmount() {
    const amt = Number(draft.amount) || 0
    if (amt <= 0) return
    if (draft.bucket === 'from_budget') {
      const { recommendedPct } = getRewardOptions(amt)
      setDraft((d) => ({ ...d, rewardPct: recommendedPct }))
      setStep('reward')
    } else {
      submitDirectDeposit(amt)
    }
  }

  function submitDirectDeposit(amount) {
    const tx = {
      type: 'deposit',
      amount,
      source: draft.reasonValue,
      note: draft.note || draft.reasonLabel,
      category: draft.category,
      budgetImpact: false,
    }
    onSubmit(tx)
    setLastResult({ moved: amount, protected: null })
    setStep('success')
  }

  function submitAvoidedSpend(rewardAmount, rewardPct) {
    const resistedAmount = Number(draft.amount) || 0
    const tx = {
      type: 'deposit',
      amount: rewardAmount,
      source: draft.reasonValue,
      note: draft.note || draft.reasonLabel,
      category: draft.category,
      budgetImpact: true,
      resistedAmount,
      rewardPercentage: rewardPct,
    }
    onSubmit(tx)
    setLastResult({ moved: rewardAmount, protected: resistedAmount })
    setStep('success')
  }

  const resistedAmount = Number(draft.amount) || 0
  const rewardInfo = draft.bucket === 'from_budget' ? getRewardOptions(resistedAmount) : null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={handleClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-x-0 border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />

        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          {step !== 'bucket' && step !== 'success' ? (
            <button onClick={() => setStep(stepBack(step, draft))} className="p-1 -ml-1">
              <ChevronLeft size={20} strokeWidth={2.4} />
            </button>
          ) : (
            <span className="w-6" />
          )}
          <p className="font-display font-bold text-sm text-ink/60">Add a crumb</p>
          <button onClick={handleClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-1">
          {step === 'bucket' && (
            <div className="flex flex-col gap-3">
              <h2 className="font-display text-xl font-bold mb-1">Where did this crumb come from?</h2>
              {crumbSourceGroups.map((group) => (
                <button
                  key={group.key}
                  onClick={() => chooseBucket(group.key)}
                  className="text-left rounded-chunky-md border-[3px] border-ink bg-paper p-4 shadow-sticker-sm active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
                >
                  <div className="flex items-center gap-2 mb-1">
                    {group.key === 'from_budget' ? (
                      <PiggyBank size={18} strokeWidth={2.4} />
                    ) : (
                      <GiftIcon size={18} strokeWidth={2.4} />
                    )}
                    <p className="font-bold text-ink">{group.title}</p>
                  </div>
                  <p className="text-sm text-ink/60">{group.subtitle}</p>
                </button>
              ))}
            </div>
          )}

          {step === 'reason' && (
            <div>
              <h2 className="font-display text-xl font-bold mb-3">What did you skip or save?</h2>
              <div className="flex flex-col gap-2">
                {crumbSourceGroups
                  .find((g) => g.key === draft.bucket)
                  .options.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => chooseReason(opt)}
                      className="text-left rounded-chunky-sm border-[3px] border-ink bg-paper px-4 py-3 font-bold text-ink shadow-sticker-sm active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
                    >
                      {opt.label}
                    </button>
                  ))}
              </div>
            </div>
          )}

          {step === 'amount' && (
            <div>
              <h2 className="font-display text-xl font-bold mb-1">
                {draft.bucket === 'from_budget' ? 'How much would you have spent?' : 'How much are you adding?'}
              </h2>
              <p className="text-sm text-ink/60 mb-4">{draft.reasonLabel}</p>
              <input
                autoFocus
                type="number"
                inputMode="decimal"
                placeholder="₹0"
                value={draft.amount}
                onChange={(e) => setDraft((d) => ({ ...d, amount: e.target.value }))}
                className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-4 py-3 text-2xl font-bold outline-none mb-3"
              />
              <input
                type="text"
                placeholder="Add a note (optional)"
                value={draft.note}
                onChange={(e) => setDraft((d) => ({ ...d, note: e.target.value }))}
                className="w-full rounded-chunky-sm border-2 border-ink/30 bg-paper px-4 py-2.5 text-sm outline-none mb-5"
              />
              <Button
                accent="yellow"
                size="lg"
                className="w-full"
                disabled={(Number(draft.amount) || 0) <= 0}
                onClick={goToNextAfterAmount}
              >
                Continue
              </Button>
            </div>
          )}

          {step === 'reward' && rewardInfo && (
            <RewardStep
              resistedAmount={resistedAmount}
              rewardInfo={rewardInfo}
              draft={draft}
              setDraft={setDraft}
              onConfirm={(amount, pct) => submitAvoidedSpend(amount, pct)}
            />
          )}

          {step === 'success' && lastResult && (
            <SuccessStep result={lastResult} onDone={handleClose} />
          )}
        </div>
      </div>
    </div>
  )
}

function stepBack(step) {
  if (step === 'reason') return 'bucket'
  if (step === 'amount') return 'reason'
  if (step === 'reward') return 'amount'
  return 'bucket'
}

function RewardStep({ resistedAmount, rewardInfo, draft, setDraft, onConfirm }) {
  const [customOpen, setCustomOpen] = useState(false)
  const selectedPct = draft.rewardPct
  const isCustom = selectedPct === 'custom'
  const customAmount = Math.min(resistedAmount, Math.max(0, Number(draft.customReward) || 0))
  const finalAmount = isCustom ? customAmount : Math.round((resistedAmount * (selectedPct ?? 0)) / 100)

  return (
    <div>
      <h2 className="font-display text-xl font-bold mb-1">
        You skipped spending {formatCurrency(resistedAmount)}.
      </h2>
      <p className="text-sm text-ink/60 mb-4">How much would you like to move to crumbs?</p>

      {rewardInfo.isLarge && (
        <div className="rounded-chunky-sm border-2 border-ink bg-yellow px-3 py-2.5 text-sm font-medium mb-4">
          This is a large resisted purchase. Consider moving a smaller reward amount to crumbs — custom keeps it
          flexible.
        </div>
      )}

      <div className="flex flex-col gap-2 mb-4">
        {rewardInfo.options.map((opt) => (
          <label
            key={opt.pct}
            className={`flex items-center justify-between rounded-chunky-sm border-[3px] border-ink px-4 py-3 cursor-pointer ${
              selectedPct === opt.pct ? 'bg-green' : 'bg-paper'
            }`}
          >
            <span className="flex items-center gap-2">
              <input
                type="radio"
                checked={selectedPct === opt.pct}
                onChange={() => {
                  setDraft((d) => ({ ...d, rewardPct: opt.pct }))
                  setCustomOpen(false)
                }}
                className="accent-ink h-4 w-4"
              />
              <span className="font-bold">
                {formatCurrency(opt.amount)} — {opt.pct}%
              </span>
            </span>
            {rewardInfo.recommendedPct === opt.pct && (
              <span className="text-[10px] font-bold uppercase tracking-wide text-ink/50">Suggested</span>
            )}
          </label>
        ))}

        <label
          className={`flex flex-col gap-2 rounded-chunky-sm border-[3px] border-ink px-4 py-3 cursor-pointer ${
            isCustom ? 'bg-blue' : 'bg-paper'
          }`}
        >
          <span className="flex items-center gap-2">
            <input
              type="radio"
              checked={isCustom}
              onChange={() => {
                setDraft((d) => ({ ...d, rewardPct: 'custom' }))
                setCustomOpen(true)
              }}
              className="accent-ink h-4 w-4"
            />
            <span className="font-bold">Custom</span>
          </span>
          {(isCustom || customOpen) && (
            <input
              type="number"
              inputMode="decimal"
              max={resistedAmount}
              min={0}
              placeholder={`Up to ${formatCurrency(resistedAmount)}`}
              value={draft.customReward}
              onChange={(e) => setDraft((d) => ({ ...d, customReward: e.target.value, rewardPct: 'custom' }))}
              className="w-full rounded-chunky-sm border-2 border-ink bg-paper px-3 py-2 font-bold outline-none"
            />
          )}
        </label>
      </div>

      <div className="rounded-chunky-sm border-2 border-ink/20 bg-paper/60 px-4 py-3 text-sm mb-4 space-y-1">
        <div className="flex justify-between">
          <span className="text-ink/60">Skipped amount</span>
          <span className="font-bold">{formatCurrency(resistedAmount)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-ink/60">Moved to crumbs</span>
          <span className="font-bold">{formatCurrency(finalAmount)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-ink/60">Money protected</span>
          <span className="font-bold">{formatCurrency(resistedAmount)}</span>
        </div>
      </div>

      <Button
        accent="green"
        size="lg"
        className="w-full"
        disabled={selectedPct == null || (isCustom && customAmount <= 0)}
        onClick={() => onConfirm(finalAmount, isCustom ? Math.round((finalAmount / resistedAmount) * 100) : selectedPct)}
      >
        Move to crumbs
      </Button>
    </div>
  )
}

function SuccessStep({ result, onDone }) {
  return (
    <div className="text-center py-4">
      <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border-[3px] border-ink bg-green text-3xl">
        🎉
      </div>
      <h2 className="font-display text-xl font-bold mb-2">
        {formatCurrency(result.moved)} moved to crumbs
      </h2>
      {result.protected != null && (
        <p className="text-sm text-ink/60 mb-1">
          You protected {formatCurrency(result.protected)} and moved {formatCurrency(result.moved)} to future-you.
        </p>
      )}
      <Button accent="yellow" size="lg" className="w-full mt-5" onClick={onDone}>
        Nice
      </Button>
    </div>
  )
}

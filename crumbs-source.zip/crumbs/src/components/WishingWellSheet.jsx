import { useMemo, useState } from 'react'
import { X, Plus, Check, Trash2 } from 'lucide-react'
import { SheetHandle, Button, bgClass } from './primitives'
import { formatCurrency } from '../utils/currency'
import { getWishSummary } from '../utils/wishes'
import Coin from './Coin'

// Full Wishing Well detail — add/manage every wish, a weekly/monthly
// summary of crumbs + wishlist activity + coins tossed, and a coin-grid
// visual (pending vs achieved) you can tap into for detail.
export default function WishingWellSheet({
  open,
  wishes,
  transactions,
  wishlist,
  onClose,
  onAdd,
  onSetStatus,
  onDelete,
}) {
  const [range, setRange] = useState('week')
  const [text, setText] = useState('')
  const [selectedId, setSelectedId] = useState(null)
  const [poppingId, setPoppingId] = useState(null)

  const summary = useMemo(
    () => getWishSummary(transactions, wishlist, wishes, { range }),
    [transactions, wishlist, wishes, range]
  )

  if (!open) return null

  function handleAdd() {
    const trimmed = text.trim()
    if (!trimmed) return
    onAdd(trimmed)
    setText('')
  }

  function handleCoinClick(id) {
    setSelectedId(id === selectedId ? null : id)
    setPoppingId(id)
    setTimeout(() => setPoppingId((p) => (p === id ? null : p)), 500)
  }

  const sorted = [...wishes].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
  const selected = sorted.find((w) => w.id === selectedId) || null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <span className="w-6" />
          <p className="font-display font-bold text-sm text-ink/60">Wishing Well</p>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-1 flex flex-col gap-6">
          <div className="flex gap-2">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
              placeholder="A wish, big or small…"
              className="min-w-0 flex-1 rounded-chunky-sm border-2 border-ink bg-paper px-3 py-2.5 text-sm font-medium outline-none"
            />
            <Button accent="yellow" disabled={!text.trim()} onClick={handleAdd}>
              <Plus size={16} strokeWidth={2.6} />
            </Button>
          </div>

          <div>
            <div className="flex gap-2 mb-3">
              <RangeButton active={range === 'week'} onClick={() => setRange('week')}>
                This week
              </RangeButton>
              <RangeButton active={range === 'month'} onClick={() => setRange('month')}>
                This month
              </RangeButton>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <SummaryTile label="Crumbs saved" value={formatCurrency(summary.crumbsSaved)} accent="green" />
              <SummaryTile label="Crumbs spent" value={formatCurrency(summary.crumbsSpent)} accent="coral" />
              <SummaryTile label="Crumbs left" value={formatCurrency(summary.crumbsLeft)} accent="yellow" />
              <SummaryTile label="Coins tossed" value={summary.coinsAdded} accent="purple" />
              <SummaryTile label="Wishlisted" value={summary.productsWishlisted} accent="blue" />
              <SummaryTile label="Bought" value={summary.productsBought} accent="pink" />
            </div>
          </div>

          <div>
            <h3 className="font-display font-bold text-sm text-ink/70 mb-2.5">
              Your coins
              <span className="ml-2 font-body font-medium text-ink/40 normal-case">
                pending = gold, achieved = green
              </span>
            </h3>
            {sorted.length === 0 ? (
              <p className="text-sm text-ink/50">No wishes tossed in yet.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {sorted.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => handleCoinClick(w.id)}
                    className={`rounded-full transition-transform ${
                      selectedId === w.id ? 'scale-110 ring-2 ring-ink ring-offset-2 ring-offset-cream' : ''
                    } ${poppingId === w.id ? 'animate-coin-pop' : ''}`}
                  >
                    <Coin achieved={w.status === 'achieved'} size={40} />
                  </button>
                ))}
              </div>
            )}

            {selected && (
              <div className="mt-3 rounded-chunky-sm border-2 border-ink bg-paper px-3.5 py-3 flex flex-col gap-2">
                <p className="text-sm font-bold text-ink leading-snug">{selected.text}</p>
                <p className="text-xs text-ink/50">
                  {selected.status === 'achieved'
                    ? `Achieved ${new Date(selected.achievedAt).toLocaleDateString()}`
                    : `Added ${new Date(selected.createdAt).toLocaleDateString()}`}
                </p>
                <div className="flex gap-2 mt-1">
                  {selected.status !== 'achieved' ? (
                    <button
                      onClick={() => onSetStatus(selected.id, 'achieved')}
                      className="flex-1 rounded-chunky-sm border-2 border-ink bg-green px-2 py-1.5 text-xs font-bold"
                    >
                      Mark achieved
                    </button>
                  ) : (
                    <button
                      onClick={() => onSetStatus(selected.id, 'pending')}
                      className="flex-1 rounded-chunky-sm border-2 border-ink bg-paper px-2 py-1.5 text-xs font-bold"
                    >
                      Move back to pending
                    </button>
                  )}
                  <button
                    onClick={() => {
                      onDelete(selected.id)
                      setSelectedId(null)
                    }}
                    className="flex h-8 w-8 items-center justify-center rounded-chunky-sm border-2 border-ink bg-paper"
                  >
                    <Trash2 size={13} strokeWidth={2.4} className="text-coral-dark" />
                  </button>
                </div>
              </div>
            )}
          </div>

          <div>
            <h3 className="font-display font-bold text-sm text-ink/70 mb-2.5">All wishes</h3>
            {sorted.length === 0 ? (
              <p className="text-sm text-ink/50 py-4 text-center">Nothing here yet — add one above.</p>
            ) : (
              <div className="flex flex-col gap-2">
                {sorted.map((w) => (
                  <div
                    key={w.id}
                    className="flex items-center gap-2.5 rounded-chunky-sm border-2 border-ink/15 bg-paper px-3 py-2.5"
                  >
                    <button
                      onClick={() => onSetStatus(w.id, w.status === 'achieved' ? 'pending' : 'achieved')}
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 border-ink ${
                        w.status === 'achieved' ? 'bg-green' : 'bg-paper'
                      }`}
                    >
                      {w.status === 'achieved' && <Check size={13} strokeWidth={3} />}
                    </button>
                    <span
                      className={`min-w-0 flex-1 truncate text-sm font-medium ${
                        w.status === 'achieved' ? 'text-ink/40 line-through' : 'text-ink/80'
                      }`}
                    >
                      {w.text}
                    </span>
                    <button onClick={() => onDelete(w.id)} className="shrink-0 p-1">
                      <Trash2 size={14} strokeWidth={2.2} className="text-ink/30" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function RangeButton({ active, children, ...rest }) {
  return (
    <button
      className={`flex-1 rounded-chunky-sm border-[3px] border-ink px-3 py-2 text-sm font-bold transition-transform ${
        active ? 'bg-yellow translate-x-[2px] translate-y-[2px] shadow-none' : 'bg-paper shadow-sticker-sm'
      }`}
      {...rest}
    >
      {children}
    </button>
  )
}

function SummaryTile({ label, value, accent }) {
  return (
    <div className={`rounded-chunky-sm border-2 border-ink ${bgClass(accent)} px-3 py-2.5`}>
      <p className="text-[10px] font-bold uppercase tracking-wide text-ink/60">{label}</p>
      <p className="text-lg font-bold text-ink mt-0.5">{value}</p>
    </div>
  )
}

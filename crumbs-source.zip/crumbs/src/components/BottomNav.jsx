import { Home, Gift, Compass, Wallet, Settings } from 'lucide-react'

const TABS = [
  { key: 'home', label: 'Home', icon: Home },
  { key: 'wishlist', label: 'Wishlist', icon: Gift },
  { key: 'planner', label: 'Planner', icon: Compass },
  { key: 'wallet', label: 'Wallet', icon: Wallet },
  { key: 'settings', label: 'Settings', icon: Settings },
]

export default function BottomNav({ active, onChange }) {
  return (
    <nav className="shrink-0 bg-paper border-t-[3px] border-ink px-2 pt-1.5 pb-[max(0.375rem,env(safe-area-inset-bottom))]">
      <div className="flex justify-between">
        {TABS.map(({ key, label, icon: Icon }) => {
          const isActive = active === key
          return (
            <button
              key={key}
              onClick={() => onChange(key)}
              className="flex flex-1 flex-col items-center gap-0.5 py-1.5 rounded-chunky-sm"
            >
              <span
                className={`flex h-8 w-8 items-center justify-center rounded-chunky-sm border-2 transition-colors ${
                  isActive ? 'bg-yellow border-ink' : 'border-transparent'
                }`}
              >
                <Icon size={18} strokeWidth={2.4} className="text-ink" />
              </span>
              <span className={`text-[11px] ${isActive ? 'font-bold text-ink' : 'text-ink/50 font-medium'}`}>
                {label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}

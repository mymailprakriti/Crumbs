import { Button } from './primitives'

export default function EmptyState({ emoji = '🍞', title, subtitle, actionLabel, onAction, accent = 'yellow' }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-6">
      <div className="h-16 w-16 flex items-center justify-center rounded-chunky-md border-[3px] border-ink bg-paper shadow-sticker-sm text-3xl mb-4">
        {emoji}
      </div>
      <p className="font-display font-bold text-lg text-ink mb-1">{title}</p>
      {subtitle && <p className="text-sm text-ink/60 max-w-[26ch]">{subtitle}</p>}
      {actionLabel && (
        <Button accent={accent} className="mt-5" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  )
}

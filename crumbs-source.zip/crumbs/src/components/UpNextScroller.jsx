import { Gift, Check, Clock3 } from 'lucide-react'
import { Card, bgClass } from './primitives'
import { formatCurrency } from '../utils/currency'
import { getCategoryColor } from '../utils/categories'

// Horizontal "what can I buy next" strip — soonest-to-acquire wishlist
// items first, each a small framed photo card matching the Wishlist/
// Planner card language (inset photo, info below). Lives above the Crumb
// Jar card on the Dashboard.
export default function UpNextScroller({ entries, categories, onSelectItem }) {
  if (entries.length === 0) return null

  return (
    <section>
      <h3 className="font-display font-bold text-sm text-ink/70 mb-2 px-0.5">Up next</h3>
      <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4 pb-2">
        {entries.map(({ item, canBuyNow, weeksNeeded }) => {
          const accent = getCategoryColor(categories, item.category)
          return (
            <Card
              as="button"
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="w-32 shrink-0 text-left p-2 flex flex-col gap-2 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            >
              <div className="relative">
                <div className="relative aspect-square w-full overflow-hidden rounded-chunky-sm border-2 border-ink/15">
                  {item.image ? (
                    <img src={item.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
                  ) : (
                    <div className={`absolute inset-0 flex items-center justify-center ${bgClass(accent)}`}>
                      <Gift size={24} strokeWidth={1.8} className="text-ink/40" />
                    </div>
                  )}
                </div>
                <span
                  className={`absolute bottom-0 right-1.5 flex h-6 w-6 translate-y-1/2 items-center justify-center rounded-chunky-sm border-2 border-ink ${
                    canBuyNow ? 'bg-green' : 'bg-paper'
                  }`}
                >
                  {canBuyNow ? (
                    <Check size={11} strokeWidth={3} />
                  ) : (
                    <Clock3 size={10} strokeWidth={2.4} className="text-ink/60" />
                  )}
                </span>
              </div>
              <div className="px-0.5 pt-1">
                <p className="text-xs font-bold text-ink truncate leading-tight">{item.name}</p>
                <p className="text-[11px] text-ink/50 truncate">{formatCurrency(item.price)}</p>
                <p className="text-[10px] font-medium text-ink/40 mt-0.5">
                  {canBuyNow
                    ? 'Ready'
                    : weeksNeeded == null
                    ? 'Add saving rate'
                    : weeksNeeded === 0
                    ? 'This week'
                    : `~${weeksNeeded} wk${weeksNeeded > 1 ? 's' : ''}`}
                </p>
              </div>
            </Card>
          )
        })}
      </div>
    </section>
  )
}

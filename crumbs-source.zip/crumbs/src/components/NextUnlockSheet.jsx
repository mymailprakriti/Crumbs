import { X } from 'lucide-react'
import { SheetHandle } from './primitives'
import WishlistCard from './WishlistCard'

// Opened by tapping the Dashboard's "Next unlock" card — the full queue of
// active items that aren't buyable yet, soonest-first, instead of just the
// single next one.
export default function NextUnlockSheet({ open, entries, categories, crumbBalance, onSelectItem, onClose }) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-ink/40 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-[480px] max-h-[88svh] overflow-y-auto rounded-t-chunky-lg border-t-[3px] border-ink bg-cream shadow-sticker-lg animate-sheet-up">
        <SheetHandle />
        <div className="flex items-center justify-between px-5 pt-3 pb-2">
          <span className="w-6" />
          <p className="font-display font-bold text-sm text-ink/60">Next unlocks</p>
          <button onClick={onClose} className="p-1 -mr-1">
            <X size={20} strokeWidth={2.4} />
          </button>
        </div>

        <div className="px-5 pb-8 pt-2">
          {entries.length === 0 ? (
            <p className="text-sm text-ink/50 py-8 text-center">
              Nothing queued up — everything active is already buyable.
            </p>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {entries.map(({ item, amountNeeded, canBuyNow, weeksNeeded }) => (
                <WishlistCard
                  key={item.id}
                  item={item}
                  categories={categories}
                  crumbBalance={crumbBalance}
                  amountNeeded={amountNeeded}
                  canBuyNow={canBuyNow}
                  weeksNeeded={weeksNeeded}
                  onClick={() => {
                    onSelectItem(item)
                    onClose()
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

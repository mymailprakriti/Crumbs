import { Card, bgClass } from './primitives'
import { formatCurrency } from '../utils/currency'
import { sourceColor, sourceLabel } from '../theme'
import { ArrowDownLeft, ArrowUpRight } from 'lucide-react'

export default function TransactionItem({ tx }) {
  const isDeposit = tx.type === 'deposit'
  const accent = sourceColor[tx.source] || (isDeposit ? 'green' : 'coral')
  const label = tx.note || sourceLabel[tx.source] || (isDeposit ? 'Crumb added' : 'Crumb spent')

  return (
    <Card className="p-3.5 flex items-start gap-3">
      <span
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-chunky-sm border-2 border-ink ${bgClass(
          accent
        )}`}
      >
        {isDeposit ? (
          <ArrowDownLeft size={16} strokeWidth={2.6} className="text-ink" />
        ) : (
          <ArrowUpRight size={16} strokeWidth={2.6} className="text-ink" />
        )}
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="font-bold text-ink text-sm truncate">{label}</p>
          <p className={`font-bold text-sm shrink-0 ${isDeposit ? 'text-green-dark' : 'text-coral-dark'}`}>
            {isDeposit ? '+' : '-'} {formatCurrency(tx.amount)}
          </p>
        </div>

        {tx.resistedAmount != null && (
          <p className="text-xs text-ink/60 mt-0.5">
            Moved {tx.rewardPercentage}% to crumbs · Protected {formatCurrency(tx.resistedAmount)}
          </p>
        )}
        {tx.linkedWishlistItemId && !tx.resistedAmount && (
          <p className="text-xs text-ink/60 mt-0.5">Wishlist purchase</p>
        )}
        <p className="text-[11px] text-ink/40 mt-0.5">
          {new Date(tx.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
        </p>
      </div>
    </Card>
  )
}

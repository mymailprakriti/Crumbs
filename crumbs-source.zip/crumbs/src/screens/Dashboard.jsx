import { useMemo, useState } from 'react'
import { PiggyBank, TrendingUp, ShieldCheck, Gift, Unlock, Plus, Sparkles, Calculator as CalculatorIcon } from 'lucide-react'
import DashboardCard from '../components/DashboardCard'
import TransactionItem from '../components/TransactionItem'
import EmptyState from '../components/EmptyState'
import QuickCalculator from '../components/QuickCalculator'
import Calculator from '../components/Calculator'
import UpNextScroller from '../components/UpNextScroller'
import WishingWellCard from '../components/WishingWellCard'
import CrumbJarGauge from '../components/CrumbJarGauge'
import { bgDarkClass } from '../components/primitives'
import { formatCurrency } from '../utils/currency'
import { getCrumbsAddedThisMonth, getMoneyProtected, countBuyableNow, getNextUnlock, getUpNextOrder } from '../utils/calculations'
import { startOfMonthKey } from '../utils/week'
import { getDailyQuote, getDailyHeadline } from '../data/quotes'

export default function Dashboard({
  settings,
  transactions,
  wishlist,
  categories,
  wishes,
  crumbBalance,
  weeklyCrumbRate,
  depositPulse,
  onOpenAddCrumb,
  onOpenAddWishlist,
  onOpenItem,
  onOpenCrumbBreakdown,
  onAddWish,
  onTouchWish,
  onSetWishStatus,
  onOpenWishingWell,
  onOpenNextUnlock,
  onGoTo,
}) {
  const [showCalc, setShowCalc] = useState(false)
  const [showCalculator, setShowCalculator] = useState(false)
  const monthKey = startOfMonthKey()

  const crumbsThisMonth = getCrumbsAddedThisMonth(transactions, monthKey)
  const moneyProtectedThisMonth = getMoneyProtected(transactions, { monthKey })
  const buyableNow = countBuyableNow(wishlist, crumbBalance)
  const nextUnlock = useMemo(
    () => getNextUnlock(wishlist, crumbBalance, weeklyCrumbRate),
    [wishlist, crumbBalance, weeklyCrumbRate]
  )
  const recent = [...transactions].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5)
  const upNext = useMemo(
    () => getUpNextOrder(wishlist, crumbBalance, weeklyCrumbRate).slice(0, 10),
    [wishlist, crumbBalance, weeklyCrumbRate]
  )
  const quote = useMemo(() => getDailyQuote(), [])
  const headline = useMemo(() => getDailyHeadline(), [])
  const savingTarget = settings.crumbSavingTarget || 0
  const savingPct = savingTarget > 0 ? Math.min(100, (crumbBalance / savingTarget) * 100) : 0

  return (
    <div className="px-4 pt-5 pb-6 flex flex-col gap-5">
      <header>
        <h1 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight">{headline}</h1>
        <p className="text-sm text-ink/50 font-medium italic mt-1.5">{quote}</p>
      </header>

      <UpNextScroller entries={upNext} categories={categories} onSelectItem={onOpenItem} />

      <div className="grid grid-cols-2 gap-3">
        <DashboardCard
          label="Crumb Jar"
          value={formatCurrency(crumbBalance)}
          sublabel="Guilt-free money, ready to use"
          accent="yellow"
          visual={<CrumbJarGauge pct={savingPct} size={60} pulseKey={depositPulse} />}
          size="lg"
          layout="row"
          onClick={onOpenCrumbBreakdown}
        />
        <DashboardCard
          label="Saving rate"
          value={`${formatCurrency(weeklyCrumbRate)}/wk`}
          accent="blue"
          icon={TrendingUp}
        />
        <DashboardCard
          label="Money protected"
          value={formatCurrency(moneyProtectedThisMonth)}
          sublabel="this month"
          accent="green"
          icon={ShieldCheck}
        />
        <DashboardCard
          label="Crumbs added"
          value={formatCurrency(crumbsThisMonth)}
          sublabel="this month"
          accent="purple"
          icon={PiggyBank}
        />
        <DashboardCard
          label="You can buy"
          value={`${buyableNow} item${buyableNow === 1 ? '' : 's'}`}
          accent="pink"
          icon={Gift}
          onClick={() => onGoTo('planner')}
        />
        <DashboardCard
          label="Next unlock"
          value={nextUnlock ? nextUnlock.item.name : '—'}
          sublabel={
            nextUnlock
              ? `in ${nextUnlock.daysNeeded} day${nextUnlock.daysNeeded === 1 ? '' : 's'}`
              : 'Add a wishlist item'
          }
          accent="coral"
          icon={Unlock}
          onClick={nextUnlock ? onOpenNextUnlock : undefined}
        />
      </div>

      <WishingWellCard
        wishes={wishes}
        onAdd={onAddWish}
        onTouch={onTouchWish}
        onSetStatus={onSetWishStatus}
        onOpenSheet={onOpenWishingWell}
      />

      <div className="grid grid-cols-4 gap-2">
        <QuickAction icon={Plus} label="Add Crumb" accent="yellow" onClick={onOpenAddCrumb} />
        <QuickAction icon={Gift} label="Add Wish" accent="pink" onClick={onOpenAddWishlist} />
        <QuickAction
          icon={Sparkles}
          label="Can I Buy?"
          accent="blue"
          onClick={() => {
            setShowCalc((s) => !s)
            setShowCalculator(false)
          }}
        />
        <QuickAction
          icon={CalculatorIcon}
          label="Calculator"
          accent="purple"
          onClick={() => {
            setShowCalculator((s) => !s)
            setShowCalc(false)
          }}
        />
      </div>

      {showCalc && <QuickCalculator crumbBalance={crumbBalance} weeklyCrumbRate={weeklyCrumbRate} wishlistItems={wishlist} />}
      {showCalculator && <Calculator />}

      <section>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-display font-bold">Recent activity</h3>
          <button className="text-xs font-bold text-ink/50" onClick={() => onGoTo('wallet')}>
            See all
          </button>
        </div>
        {recent.length === 0 ? (
          <EmptyState
            emoji="🍞"
            title="No crumbs yet."
            subtitle="Add your first crumb and start building your guilt-free fund."
            actionLabel="Add Crumb"
            onAction={onOpenAddCrumb}
          />
        ) : (
          <div className="flex flex-col gap-2">
            {recent.map((tx) => (
              <TransactionItem key={tx.id} tx={tx} />
            ))}
          </div>
        )}
      </section>
    </div>
  )
}

function QuickAction({ icon: Icon, label, accent, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 rounded-chunky-md border-[3px] border-ink ${bgDarkClass(
        accent
      )} py-3 shadow-sticker-sm active:translate-x-[2px] active:translate-y-[2px] active:shadow-none`}
    >
      <Icon size={18} strokeWidth={2.4} />
      <span className="text-[11px] font-bold text-center leading-tight px-0.5">{label}</span>
    </button>
  )
}

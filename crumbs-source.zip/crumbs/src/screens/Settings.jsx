import { useRef, useState } from 'react'
import { Download, Upload, RotateCcw, Info, Tags, ChevronRight, Check } from 'lucide-react'
import { Card, Button, bgClass } from '../components/primitives'
import { downloadJSON, parseImportedJSON } from '../utils/storage'
import { THEMES } from '../data/themes'
import { getContrastText } from '../utils/color'

export default function Settings({
  settings,
  onUpdateSettings,
  appState,
  onImportState,
  onResetData,
  categories,
  onOpenCategoryManager,
}) {
  const fileInputRef = useRef(null)
  const [confirmReset, setConfirmReset] = useState(false)
  const [importMsg, setImportMsg] = useState('')
  const [exportMsg, setExportMsg] = useState('')

  async function handleExport() {
    setExportMsg('')
    const ok = await downloadJSON(appState, `crumbs-backup-${Date.now()}.json`)
    setExportMsg(ok ? 'Backup ready — check your downloads.' : 'Could not save the backup.')
  }

  function handleImportFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const parsed = parseImportedJSON(reader.result)
        onImportState(parsed)
        setImportMsg('Backup imported.')
      } catch (err) {
        setImportMsg('Could not read that file — is it a Crumbs backup?')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  return (
    <div className="px-4 pt-5 pb-6 flex flex-col gap-5">
      <header>
        <h1 className="font-display text-2xl font-bold">Settings</h1>
      </header>

      <Card className="p-4 flex flex-col gap-4">
        <SectionTitle>Weekly budget</SectionTitle>
        <Field label="Weekly personal spending budget">
          <AmountInput
            value={settings.weeklyBudget}
            onChange={(v) => onUpdateSettings({ weeklyBudget: v })}
          />
        </Field>
      </Card>

      <Card className="p-4 flex flex-col gap-4">
        <SectionTitle>Saving rate</SectionTitle>
        <div className="flex gap-2">
          <ModeButton
            active={settings.savingRateMode === 'manual'}
            onClick={() => onUpdateSettings({ savingRateMode: 'manual' })}
          >
            Manual
          </ModeButton>
          <ModeButton
            active={settings.savingRateMode === 'auto'}
            onClick={() => onUpdateSettings({ savingRateMode: 'auto' })}
          >
            Auto-estimated
          </ModeButton>
        </div>
        {settings.savingRateMode === 'manual' ? (
          <Field label="I usually save this much in crumbs per week">
            <AmountInput
              value={settings.manualWeeklyCrumbRate}
              onChange={(v) => onUpdateSettings({ manualWeeklyCrumbRate: v })}
            />
          </Field>
        ) : (
          <p className="text-xs text-ink/50 flex items-start gap-1.5">
            <Info size={14} className="shrink-0 mt-0.5" />
            Estimated automatically from your crumb deposits over the last 4 weeks.
          </p>
        )}
      </Card>

      <Card className="p-4 flex flex-col gap-3">
        <SectionTitle>Currency</SectionTitle>
        <div className="rounded-chunky-sm border-2 border-ink/20 bg-paper px-4 py-2.5 text-sm font-bold">
          INR — Indian Rupee (₹)
        </div>
      </Card>

      <Card className="p-4 flex flex-col gap-3">
        <SectionTitle>Appearance</SectionTitle>
        <p className="text-xs text-ink/50 -mt-1">Pick a color theme for the whole app.</p>
        <div className="grid grid-cols-2 gap-2.5">
          {THEMES.map((theme) => (
            <ThemeCard
              key={theme.id}
              theme={theme}
              active={(settings.themeId || 'classic') === theme.id}
              onSelect={() => onUpdateSettings({ themeId: theme.id })}
            />
          ))}
        </div>
      </Card>

      <Card className="p-4 flex flex-col gap-3">
        <SectionTitle>Categories</SectionTitle>
        <div className="flex flex-wrap gap-1.5">
          {categories.map((cat) => (
            <span
              key={cat.id}
              className="inline-flex items-center gap-1.5 rounded-chunky-sm border-2 border-ink bg-paper px-2.5 py-1 text-xs font-bold"
            >
              <span className={`h-2.5 w-2.5 rounded-full border border-ink ${bgClass(cat.color)}`} />
              {cat.name}
            </span>
          ))}
        </div>
        <Button variant="outline" className="justify-between" onClick={onOpenCategoryManager}>
          <span className="flex items-center gap-2">
            <Tags size={16} strokeWidth={2.4} /> Add, edit or remove categories
          </span>
          <ChevronRight size={16} strokeWidth={2.4} />
        </Button>
      </Card>

      <Card className="p-4 flex flex-col gap-3">
        <SectionTitle>Your data</SectionTitle>
        <Button variant="outline" className="justify-start" onClick={handleExport}>
          <Download size={16} strokeWidth={2.4} /> Export data as JSON
        </Button>
        {exportMsg && <p className="text-xs text-ink/50">{exportMsg}</p>}
        <Button variant="outline" className="justify-start" onClick={() => fileInputRef.current?.click()}>
          <Upload size={16} strokeWidth={2.4} /> Import data from JSON
        </Button>
        <input ref={fileInputRef} type="file" accept="application/json" hidden onChange={handleImportFile} />
        {importMsg && <p className="text-xs text-ink/50">{importMsg}</p>}

        {!confirmReset ? (
          <Button variant="outline" accent="coral" className="justify-start" onClick={() => setConfirmReset(true)}>
            <RotateCcw size={16} strokeWidth={2.4} /> Reset data
          </Button>
        ) : (
          <div className="rounded-chunky-sm border-2 border-ink bg-coral px-4 py-3">
            <p className="text-sm font-bold mb-2">This clears everything. Are you sure?</p>
            <div className="flex gap-2">
              <Button
                size="sm"
                accent="coral"
                onClick={() => {
                  onResetData()
                  setConfirmReset(false)
                }}
              >
                Yes, reset
              </Button>
              <Button size="sm" variant="outline" onClick={() => setConfirmReset(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}
      </Card>

      <p className="text-center text-xs text-ink/30 px-6">
        Crumbs is a lightweight ledger for guilt-free money. It doesn't track your main savings, bills, or
        essentials — and it never will.
      </p>
    </div>
  )
}

function SectionTitle({ children }) {
  return <h3 className="font-display font-bold text-sm text-ink/70">{children}</h3>
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-xs font-bold text-ink/50 mb-1.5">{label}</span>
      {children}
    </label>
  )
}

function AmountInput({ value, onChange }) {
  return (
    <input
      type="number"
      inputMode="decimal"
      value={value}
      onChange={(e) => onChange(Number(e.target.value) || 0)}
      className="w-full rounded-chunky-sm border-[3px] border-ink bg-paper px-4 py-2.5 text-lg font-bold outline-none"
    />
  )
}

// Each card previews itself entirely in its own theme's colors (paper bg,
// ink text/border) rather than the app's currently-active theme, so you
// can compare options at a glance. The little swatch strip echoes the
// reference moodboards this was built from: each swatch gets a short
// label in whichever text color — white or dark ink — actually reads on
// top of that particular color, the same way each reference card's own
// "PRIMARY"/"SECONDARY" label was colored to match its swatch.
const SWATCH_SLOTS = [
  { key: 'yellow', label: 'YL' },
  { key: 'green', label: 'GR' },
  { key: 'coral', label: 'CO' },
  { key: 'pink', label: 'PK' },
  { key: 'blue', label: 'BL' },
  { key: 'purple', label: 'PU' },
]

function ThemeCard({ theme, active, onSelect }) {
  const { colors } = theme
  return (
    <button
      onClick={onSelect}
      style={{ background: colors.paper, borderColor: colors.ink }}
      className={`text-left rounded-chunky-md border-[3px] p-3 flex flex-col gap-2.5 transition-transform ${
        active ? 'translate-x-[2px] translate-y-[2px] shadow-none' : 'shadow-sticker-sm active:translate-x-[1px] active:translate-y-[1px]'
      }`}
    >
      <div className="flex items-center justify-between gap-1">
        <span className="font-bold text-sm truncate" style={{ color: colors.ink }}>
          {theme.name}
        </span>
        {active ? (
          <span
            className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2"
            style={{ background: colors.ink, borderColor: colors.ink }}
          >
            <Check size={11} strokeWidth={3} style={{ color: colors.paper }} />
          </span>
        ) : (
          <span
            className="text-[9px] font-bold uppercase tracking-wide shrink-0"
            style={{ color: colors.ink, opacity: 0.45 }}
          >
            {theme.mode}
          </span>
        )}
      </div>
      <div className="flex gap-1">
        {SWATCH_SLOTS.map(({ key, label }) => {
          const hex = colors[key]
          return (
            <span
              key={key}
              className="relative h-9 flex-1 rounded-md border-2 overflow-hidden"
              style={{ background: hex, borderColor: colors.ink }}
            >
              <span
                className="absolute top-0.5 left-1 text-[7px] font-black uppercase tracking-wide"
                style={{ color: getContrastText(hex) }}
              >
                {label}
              </span>
            </span>
          )
        })}
      </div>
    </button>
  )
}

function ModeButton({ active, children, ...rest }) {
  return (
    <button
      className={`flex-1 rounded-chunky-sm border-[3px] border-ink px-3 py-2 text-sm font-bold transition-transform ${
        active ? 'bg-yellow translate-x-[2px] translate-y-[2px] shadow-none' : 'bg-paper shadow-sticker-sm'
      }`}
      {...rest}
    >
      {children}
    </button>
  )
}

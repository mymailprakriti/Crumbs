import { useState } from 'react'
import TransactionItem from '../components/TransactionItem'
import EmptyState from '../components/EmptyState'
import PillFilter from '../components/PillFilter'
import { formatCurrency } from '../utils/currency'

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'deposits', label: 'Deposits' },
  { value: 'spends', label: 'Spends' },
  { value: 'avoided_spend', label: 'Avoided spends' },
  { value: 'refunds', label: 'Refunds' },
  { value: 'wishlist_purchase', label: 'Wishlist purchases' },
  { value: 'weekly_leftover', label: 'Weekly leftovers' },
]

const REFUND_SOURCES = ['refund', 'cashback', 'reimbursement']
const AVOIDED_SOURCES = ['skipped_food', 'skipped_coffee', 'skipped_cab', 'avoided_impulse', 'spent_less', 'cheaper_alt']

function matchesFilter(tx, filter) {
  switch (filter) {
    case 'all':
      return true
    case 'deposits':
      return tx.type === 'deposit'
    case 'spends':
      return tx.type === 'spend'
    case 'avoided_spend':
      return AVOIDED_SOURCES.includes(tx.source)
    case 'refunds':
      return REFUND_SOURCES.includes(tx.source)
    case 'wishlist_purchase':
      return tx.source === 'wishlist_purchase'
    case 'weekly_leftover':
      return tx.source === 'weekly_leftover'
    default:
      return true
  }
}

export default function Wallet({ transactions, crumbBalance }) {
  const [filter, setFilter] = useState('all')
  const filtered = [...transactions]
    .filter((tx) => matchesFilter(tx, filter))
    .sort((a, b) => new Date(b.date) - new Date(a.date))

  return (
    <div className="px-4 pt-5 pb-6 flex flex-col gap-4">
      <header>
        <h1 className="font-display text-2xl font-bold">Wallet</h1>
        <p className="text-sm text-ink/50">
          Balance <span className="font-bold text-ink">{formatCurrency(crumbBalance)}</span>
        </p>
      </header>

      <PillFilter options={FILTERS} value={filter} onChange={setFilter} accent="blue" />

      {filtered.length === 0 ? (
        <EmptyState
          emoji="🧾"
          title="No activity yet."
          subtitle="Your crumb history will show up here."
          accent="blue"
        />
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((tx) => (
            <TransactionItem key={tx.id} tx={tx} />
          ))}
        </div>
      )}
    </div>
  )
}

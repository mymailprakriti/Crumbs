import { useState } from 'react'
import PlannerSection from '../components/PlannerSection'
import EmptyState from '../components/EmptyState'
import SortFilterBar from '../components/SortFilterBar'
import { groupWishlistForPlanner, sortEnrichedEntries } from '../utils/calculations'

export default function Planner({ wishlist, categories, crumbBalance, weeklyCrumbRate, onOpenItem, onAddWishlist }) {
  const [sortKey, setSortKey] = useState('priority')
  const { canBuyNow, soon, longerTerm } = groupWishlistForPlanner(wishlist, crumbBalance, weeklyCrumbRate)
  const isEmpty = canBuyNow.length + soon.length + longerTerm.length === 0

  return (
    <div className="px-4 pt-5 pb-6 flex flex-col gap-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Planner</h1>
        <p className="text-sm text-ink/50">What should you buy first?</p>
      </header>

      {isEmpty ? (
        <EmptyState
          emoji="🧭"
          title="Nothing to plan yet."
          subtitle="Add a wishlist item and Crumbs will help you decide what to buy first."
          actionLabel="Add Wishlist Item"
          onAction={onAddWishlist}
          accent="blue"
        />
      ) : (
        <>
          <SortFilterBar value={sortKey} onChange={setSortKey} accent="purple" />

          <PlannerSection
            title="Can buy now"
            subtitle="Guilt-free, ready today."
            accent="green"
            entries={sortEnrichedEntries(canBuyNow, sortKey)}
            categories={categories}
            crumbBalance={crumbBalance}
            onSelectItem={onOpenItem}
          />
          <PlannerSection
            title="Soon"
            subtitle="Within about 4 weeks at your current rate."
            accent="yellow"
            entries={sortEnrichedEntries(soon, sortKey)}
            categories={categories}
            crumbBalance={crumbBalance}
            onSelectItem={onOpenItem}
          />
          <PlannerSection
            title="Longer term"
            subtitle="More than 4 weeks away — or add a saving rate to see an ETA."
            accent="purple"
            entries={sortEnrichedEntries(longerTerm, sortKey)}
            categories={categories}
            crumbBalance={crumbBalance}
            onSelectItem={onOpenItem}
          />
        </>
      )}
    </div>
  )
}

import { useEffect, useMemo, useRef, useState } from 'react'
import { Plus, ChevronLeft } from 'lucide-react'
import WishlistCard from '../components/WishlistCard'
import FolderTile from '../components/FolderTile'
import AddCategoryFolderCard from '../components/AddCategoryFolderCard'
import EmptyState from '../components/EmptyState'
import PillFilter from '../components/PillFilter'
import SortFilterBar from '../components/SortFilterBar'
import { getItemStatus, sortWishlistItems } from '../utils/calculations'
import { newId } from '../utils/id'

const VIEW_OPTIONS = [
  { value: 'folders', label: 'Folders' },
  { value: 'all', label: 'View all' },
]

const STATUS_FILTERS = [
  { value: 'active', label: 'Active' },
  { value: 'bought', label: 'Bought' },
  { value: 'archived', label: 'Archived' },
]

export default function Wishlist({
  wishlist,
  categories,
  crumbBalance,
  weeklyCrumbRate,
  onOpenItem,
  onAddWishlist,
  onAddCategory,
  onReorderCategories,
  onEditCategory,
}) {
  const [view, setView] = useState('folders')
  const [openCategory, setOpenCategory] = useState(null)
  const [statusFilter, setStatusFilter] = useState('active')
  const [sortKey, setSortKey] = useState('priority')

  // Folder drag-to-reorder: a local order that mirrors `categories` except
  // while a drag is in flight, when it's live-updated as the dragged tile
  // passes over neighbors, then committed back up on release.
  const [orderIds, setOrderIds] = useState(() => categories.map((c) => c.id))
  const [dragId, setDragId] = useState(null)
  const [dragPos, setDragPos] = useState({ dx: 0, dy: 0 })
  const dragStart = useRef({ x: 0, y: 0 })

  useEffect(() => {
    if (!dragId) setOrderIds(categories.map((c) => c.id))
  }, [categories, dragId])

  const orderedCategories = useMemo(
    () => orderIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean),
    [orderIds, categories]
  )

  const activeCounts = useMemo(() => {
    const map = new Map()
    for (const item of wishlist) {
      if (item.status !== 'active') continue
      map.set(item.category, (map.get(item.category) || 0) + 1)
    }
    return map
  }, [wishlist])

  const isEmpty = wishlist.length === 0

  function renderCard(item) {
    const { amountNeeded, canBuyNow, weeksNeeded } = getItemStatus(item, crumbBalance, weeklyCrumbRate)
    return (
      <WishlistCard
        key={item.id}
        item={item}
        categories={categories}
        crumbBalance={crumbBalance}
        amountNeeded={amountNeeded}
        canBuyNow={canBuyNow}
        weeksNeeded={weeksNeeded}
        onClick={() => onOpenItem(item)}
      />
    )
  }

  function openFolder(name) {
    setOpenCategory(name)
    setStatusFilter('active')
  }

  function handleAddCategory(name, color) {
    onAddCategory({ id: newId('cat'), name, color })
  }

  function handleDragStart(id, x, y) {
    setDragId(id)
    dragStart.current = { x, y }
    setDragPos({ dx: 0, dy: 0 })
  }

  function handleDragMove(x, y) {
    setDragPos({ dx: x - dragStart.current.x, dy: y - dragStart.current.y })
    // The dragged tile is visually translated to sit right under the
    // pointer, so a plain elementFromPoint would just keep hitting itself.
    // Walk the full z-order stack at this point and skip past it to find
    // whichever neighbor tile is actually underneath.
    const stack = document.elementsFromPoint(x, y)
    let hoverId = null
    for (const el of stack) {
      const tile = el.closest?.('[data-category-id]')
      const id = tile?.getAttribute('data-category-id')
      if (id && id !== dragId) {
        hoverId = id
        break
      }
    }
    if (hoverId) {
      setOrderIds((prev) => {
        const from = prev.indexOf(dragId)
        const to = prev.indexOf(hoverId)
        if (from === -1 || to === -1) return prev
        const next = [...prev]
        next.splice(from, 1)
        next.splice(to, 0, dragId)
        return next
      })
    }
  }

  function handleDragEnd() {
    if (dragId) onReorderCategories(orderIds)
    setDragId(null)
    setDragPos({ dx: 0, dy: 0 })
  }

  const AddButton = (
    <button
      onClick={onAddWishlist}
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-chunky-sm border-[3px] border-ink bg-yellow shadow-sticker-sm active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
    >
      <Plus size={18} strokeWidth={2.6} />
    </button>
  )

  // ---- Drilled into a single category folder ---------------------------
  if (openCategory) {
    const items = sortWishlistItems(
      wishlist.filter((i) => i.category === openCategory && i.status === statusFilter),
      sortKey
    )
    return (
      <div className="px-4 pt-5 pb-6 flex flex-col gap-4">
        <header className="flex items-center gap-2">
          <button onClick={() => setOpenCategory(null)} className="p-1 -ml-1 shrink-0">
            <ChevronLeft size={22} strokeWidth={2.4} />
          </button>
          <h1 className="font-display text-2xl font-bold flex-1 truncate">{openCategory}</h1>
          {AddButton}
        </header>

        <PillFilter options={STATUS_FILTERS} value={statusFilter} onChange={setStatusFilter} accent="pink" />
        <SortFilterBar value={sortKey} onChange={setSortKey} accent="blue" />

        {items.length === 0 ? (
          <EmptyState
            emoji="🎁"
            title={`No ${statusFilter} items here.`}
            subtitle={statusFilter === 'active' ? 'Add something you want to buy guilt-free.' : undefined}
            actionLabel={statusFilter === 'active' ? 'Add Wishlist Item' : undefined}
            onAction={onAddWishlist}
            accent="pink"
          />
        ) : (
          <div className="grid grid-cols-2 gap-3">{items.map(renderCard)}</div>
        )}
      </div>
    )
  }

  // ---- Top-level: folders or flat "view all" ----------------------------
  return (
    <div className="px-4 pt-5 pb-6 flex flex-col gap-4">
      <header className="flex items-center justify-between gap-2">
        <h1 className="font-display text-2xl font-bold">Wishlist</h1>
        {AddButton}
      </header>

      {!isEmpty && <PillFilter options={VIEW_OPTIONS} value={view} onChange={setView} accent="blue" />}

      {isEmpty ? (
        <EmptyState
          emoji="🎁"
          title="Your wishlist is empty."
          subtitle="Add something you want to buy guilt-free."
          actionLabel="Add Wishlist Item"
          onAction={onAddWishlist}
          accent="pink"
        />
      ) : view === 'folders' ? (
        <>
          <p className="text-xs text-ink/40 font-medium -mt-1">Drag a folder to reorder · press and hold to edit</p>
          <div className="grid grid-cols-2 gap-3.5 mt-1">
            {orderedCategories.map((cat) => (
              <FolderTile
                key={cat.id}
                category={cat}
                count={activeCounts.get(cat.name) || 0}
                dragId={dragId}
                dragPos={dragPos}
                onOpen={() => openFolder(cat.name)}
                onLongPress={() => onEditCategory(cat.id)}
                onDragStart={handleDragStart}
                onDragMove={handleDragMove}
                onDragEnd={handleDragEnd}
              />
            ))}
            <AddCategoryFolderCard onAdd={handleAddCategory} />
          </div>
        </>
      ) : (
        <>
          <PillFilter options={STATUS_FILTERS} value={statusFilter} onChange={setStatusFilter} accent="pink" />
          <SortFilterBar value={sortKey} onChange={setSortKey} accent="blue" />
          <AllItemsList
            items={sortWishlistItems(wishlist.filter((i) => i.status === statusFilter), sortKey)}
            statusFilter={statusFilter}
            onAddWishlist={onAddWishlist}
            renderCard={renderCard}
          />
        </>
      )}
    </div>
  )
}

function AllItemsList({ items, statusFilter, onAddWishlist, renderCard }) {
  if (items.length === 0) {
    return (
      <EmptyState
        emoji="🎁"
        title={`No ${statusFilter} items.`}
        subtitle={statusFilter === 'active' ? 'Add something you want to buy guilt-free.' : undefined}
        actionLabel={statusFilter === 'active' ? 'Add Wishlist Item' : undefined}
        onAction={onAddWishlist}
        accent="pink"
      />
    )
  }
  return <div className="grid grid-cols-2 gap-3">{items.map(renderCard)}</div>
}

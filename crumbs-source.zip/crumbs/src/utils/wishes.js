// ─────────────────────────────────────────────────────────────────────────
// WISHING WELL · a lightweight wishes + habit builder, sitting alongside
// (but separate from) the crumb-savings ledger. A "wish" is any free-form
// intention — may or may not need money — tracked as a single checklist
// item with a status, not a whole sub-task list.
// ─────────────────────────────────────────────────────────────────────────

import { isInWeek, isInMonth, weekKey, startOfMonthKey } from './week'

const STALE_DAYS = 7

export function daysSince(dateStr) {
  const then = new Date(dateStr).getTime()
  return Math.floor((Date.now() - then) / 86400000)
}

// The single longest-neglected pending wish — surfaced as a gentle nudge
// ("Any progress on ...?") once it's gone 7+ days without you touching it.
export function getStaleWish(wishes) {
  const stale = wishes
    .filter((w) => w.status === 'pending')
    .filter((w) => daysSince(w.lastInteractionAt || w.createdAt) >= STALE_DAYS)
    .sort((a, b) => new Date(a.lastInteractionAt || a.createdAt) - new Date(b.lastInteractionAt || b.createdAt))
  return stale[0] || null
}

// Weekly/monthly summary: crumbs saved & spent, what's left over this
// period, how many wishlist products were added/bought, and how many
// coins (wishes) got tossed in — for the Wishing Well sheet.
export function getWishSummary(transactions, wishlist, wishes, { range = 'week' } = {}) {
  const key = range === 'week' ? weekKey() : startOfMonthKey()
  const inRange = (dateStr) => (range === 'week' ? isInWeek(dateStr, key) : isInMonth(dateStr, key))

  const crumbsSaved = transactions
    .filter((t) => t.type === 'deposit' && inRange(t.date))
    .reduce((sum, t) => sum + t.amount, 0)

  const crumbsSpent = transactions
    .filter((t) => t.type === 'spend' && inRange(t.date))
    .reduce((sum, t) => sum + t.amount, 0)

  const productsWishlisted = wishlist.filter((i) => inRange(i.createdAt)).length
  const productsBought = transactions.filter((t) => t.linkedWishlistItemId && inRange(t.date)).length
  const coinsAdded = wishes.filter((w) => inRange(w.createdAt)).length

  return {
    crumbsSaved,
    crumbsSpent,
    crumbsLeft: crumbsSaved - crumbsSpent,
    productsWishlisted,
    productsBought,
    coinsAdded,
  }
}

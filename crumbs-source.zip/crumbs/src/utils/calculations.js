// ─────────────────────────────────────────────────────────────────────────
// CRUMBS · CALCULATION ENGINE
// Every formula in this file maps directly to a formula in the product
// spec. Kept pure (state in, value out) so screens and tests can call
// them without touching localStorage.
// ─────────────────────────────────────────────────────────────────────────

import { weekKey, isInWeek, isInMonth, weeksAgoKeys } from './week'

// ---- Crumb balance ---------------------------------------------------

export function getCrumbBalance(transactions) {
  return transactions.reduce((sum, t) => {
    if (t.type === 'deposit') return sum + t.amount
    if (t.type === 'spend') return sum - t.amount
    return sum
  }, 0)
}

// ---- Money protected ----------------------------------------------------
// Full value of everything resisted/delayed/avoided, independent of how
// much of it was actually moved into crumbs.

export function getMoneyProtected(transactions, { monthKey } = {}) {
  return transactions
    .filter((t) => t.resistedAmount != null)
    .filter((t) => (monthKey ? isInMonth(t.date, monthKey) : true))
    .reduce((sum, t) => sum + t.resistedAmount, 0)
}

export function getCrumbsAddedThisMonth(transactions, monthKey) {
  return transactions
    .filter((t) => t.type === 'deposit' && isInMonth(t.date, monthKey))
    .reduce((sum, t) => sum + t.amount, 0)
}

// ---- Saving rate ----------------------------------------------------------

export function getWeeklyCrumbRateAuto(transactions, weeksBack = 4) {
  const keys = new Set(weeksAgoKeys(weeksBack))
  const total = transactions
    .filter((t) => t.type === 'deposit' && keys.has(weekKey(new Date(t.date))))
    .reduce((sum, t) => sum + t.amount, 0)
  return total / weeksBack
}

export function getWeeklyCrumbRate(settings, transactions) {
  if (settings.savingRateMode === 'auto') {
    return getWeeklyCrumbRateAuto(transactions)
  }
  return settings.manualWeeklyCrumbRate || 0
}

// ---- Weekly budget logic --------------------------------------------------

export function getInstantCrumbsFromWeeklyBudget(transactions, key = weekKey()) {
  return transactions
    .filter((t) => t.type === 'deposit' && t.budgetImpact && isInWeek(t.date, key))
    .reduce((sum, t) => sum + t.amount, 0)
}

export function getStillSafeToSpend({ weeklyBudget, spentThisWeek, instantCrumbsFromWeeklyBudget }) {
  return weeklyBudget - spentThisWeek - instantCrumbsFromWeeklyBudget
}

export function getExtraLeftover({ weeklyBudget, totalSpentThisWeek, instantCrumbsFromWeeklyBudget }) {
  const raw = weeklyBudget - totalSpentThisWeek - instantCrumbsFromWeeklyBudget
  return Math.max(0, raw)
}

// ---- Avoided-spend reward recommendation ----------------------------------
// The core "commitment %" decision. Small skips default to 100% (you didn't
// need it anyway); larger ones nudge toward a smaller, safer share; very
// large ones get an explicit "are you sure" framing instead of an
// auto-100% suggestion.

export const LARGE_RESISTED_THRESHOLD = 20000

export function getRewardOptions(resistedAmount) {
  const pct = (p) => Math.round((resistedAmount * p) / 100)
  const options = [
    { pct: 20, amount: pct(20) },
    { pct: 50, amount: pct(50) },
    { pct: 100, amount: pct(100) },
  ]

  let recommendedPct = 100
  if (resistedAmount > LARGE_RESISTED_THRESHOLD) {
    recommendedPct = 20
  } else if (resistedAmount > 5000) {
    recommendedPct = 20
  } else if (resistedAmount > 1000) {
    recommendedPct = 50
  }

  return {
    options,
    recommendedPct,
    isLarge: resistedAmount > LARGE_RESISTED_THRESHOLD,
  }
}

// ---- Wishlist ETA -----------------------------------------------------

export function getAmountNeeded(price, crumbBalance) {
  return Math.max(0, price - crumbBalance)
}

export function getCanBuyNow(price, crumbBalance) {
  return crumbBalance >= price
}

export function getWeeksNeeded(amountNeeded, weeklyCrumbRate) {
  if (!weeklyCrumbRate || weeklyCrumbRate <= 0) return null
  if (amountNeeded <= 0) return 0
  return Math.ceil(amountNeeded / weeklyCrumbRate)
}

export function getDaysNeeded(amountNeeded, weeklyCrumbRate) {
  if (!weeklyCrumbRate || weeklyCrumbRate <= 0) return null
  if (amountNeeded <= 0) return 0
  const dailyRate = weeklyCrumbRate / 7
  return Math.ceil(amountNeeded / dailyRate)
}

export function getItemStatus(item, crumbBalance, weeklyCrumbRate) {
  const amountNeeded = getAmountNeeded(item.price, crumbBalance)
  const canBuyNow = getCanBuyNow(item.price, crumbBalance)
  const weeksNeeded = getWeeksNeeded(amountNeeded, weeklyCrumbRate)
  return { amountNeeded, canBuyNow, weeksNeeded }
}

// ---- Purchase simulator -----------------------------------------------

export function getBalanceAfterPurchase(crumbBalance, price) {
  return crumbBalance - price
}

// Returns [{ id, name, oldWeeksNeeded, newWeeksNeeded, delay }] for every
// OTHER active item whose ETA would get pushed out, sorted worst-delay first.
export function getPurchaseImpact(item, crumbBalance, wishlistItems, weeklyCrumbRate) {
  if (!weeklyCrumbRate || weeklyCrumbRate <= 0) return []
  const balanceAfter = getBalanceAfterPurchase(crumbBalance, item.price)

  return wishlistItems
    .filter((other) => other.id !== item.id && other.status === 'active')
    .map((other) => {
      const oldWeeksNeeded = getWeeksNeeded(getAmountNeeded(other.price, crumbBalance), weeklyCrumbRate)
      const newWeeksNeeded = getWeeksNeeded(getAmountNeeded(other.price, balanceAfter), weeklyCrumbRate)
      const delay = (newWeeksNeeded ?? 0) - (oldWeeksNeeded ?? 0)
      return { id: other.id, name: other.name, priority: other.priority, oldWeeksNeeded, newWeeksNeeded, delay }
    })
    .filter((d) => d.delay > 0)
    .sort((a, b) => b.delay - a.delay)
}

// ---- Planner grouping ---------------------------------------------------

export const PRIORITY_RANK = { high: 0, medium: 1, low: 2 }

export function groupWishlistForPlanner(items, crumbBalance, weeklyCrumbRate) {
  const active = items.filter((i) => i.status === 'active')

  const enriched = active.map((item) => {
    const { amountNeeded, canBuyNow, weeksNeeded } = getItemStatus(item, crumbBalance, weeklyCrumbRate)
    const impact = getPurchaseImpact(item, crumbBalance, items, weeklyCrumbRate)
    return { item, amountNeeded, canBuyNow, weeksNeeded, impactCount: impact.length }
  })

  const canBuyNow = enriched.filter((e) => e.canBuyNow)
  const soon = enriched.filter((e) => !e.canBuyNow && e.weeksNeeded != null && e.weeksNeeded <= 4)
  const longerTerm = enriched.filter((e) => !e.canBuyNow && (e.weeksNeeded == null || e.weeksNeeded > 4))

  const sorter = (a, b) => {
    const p = PRIORITY_RANK[a.item.priority] - PRIORITY_RANK[b.item.priority]
    if (p !== 0) return p
    const aw = a.weeksNeeded ?? Infinity
    const bw = b.weeksNeeded ?? Infinity
    if (aw !== bw) return aw - bw
    return a.impactCount - b.impactCount
  }

  return {
    canBuyNow: canBuyNow.sort(sorter),
    soon: soon.sort(sorter),
    longerTerm: longerTerm.sort(sorter),
  }
}

// Whole-wishlist count of "buyable now" items, for the dashboard stat.
export function countBuyableNow(items, crumbBalance) {
  return items.filter((i) => i.status === 'active' && i.price <= crumbBalance).length
}

// The soonest-unlocking item that isn't buyable yet, for "Next unlock".
export function getNextUnlock(items, crumbBalance, weeklyCrumbRate) {
  const candidates = items
    .filter((i) => i.status === 'active' && i.price > crumbBalance)
    .map((item) => {
      const status = getItemStatus(item, crumbBalance, weeklyCrumbRate)
      const daysNeeded = getDaysNeeded(status.amountNeeded, weeklyCrumbRate)
      return { item, ...status, daysNeeded }
    })
    .filter((c) => c.weeksNeeded != null)
    .sort((a, b) => a.weeksNeeded - b.weeksNeeded)

  return candidates[0] || null
}

// ---- Crumb breakdown ----------------------------------------------------
// Groups every crumb deposit by where it came from (skipped food, refund,
// cashback, manual add, ...) — answers "where am I actually getting crumbs
// from?" for the Crumb Jar breakdown sheet. Source keys line up with
// theme.js's sourceLabel / sourceColor maps.

export function getCrumbBreakdown(transactions, { monthKey } = {}) {
  const deposits = transactions
    .filter((t) => t.type === 'deposit')
    .filter((t) => (monthKey ? isInMonth(t.date, monthKey) : true))

  const total = deposits.reduce((sum, t) => sum + t.amount, 0)

  const bySource = new Map()
  for (const t of deposits) {
    const key = t.source || 'manual'
    bySource.set(key, (bySource.get(key) || 0) + t.amount)
  }

  const rows = Array.from(bySource.entries())
    .map(([source, amount]) => ({
      source,
      amount,
      pct: total > 0 ? Math.round((amount / total) * 100) : 0,
    }))
    .sort((a, b) => b.amount - a.amount)

  return { total, rows }
}

// ---- Sorting (Wishlist / Planner filter bar) -----------------------------

export function sortWishlistItems(items, sortKey) {
  const arr = [...items]
  switch (sortKey) {
    case 'priority':
      return arr.sort((a, b) => (PRIORITY_RANK[a.priority] ?? 3) - (PRIORITY_RANK[b.priority] ?? 3))
    case 'price':
      return arr.sort((a, b) => a.price - b.price)
    case 'newest':
      return arr.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    default:
      return arr
  }
}

// Same idea, but for the already-enriched `{ item, ... }` entries Planner
// works with (canBuyNow / soon / longerTerm sections).
export function sortEnrichedEntries(entries, sortKey) {
  const arr = [...entries]
  switch (sortKey) {
    case 'priority':
      return arr.sort((a, b) => (PRIORITY_RANK[a.item.priority] ?? 3) - (PRIORITY_RANK[b.item.priority] ?? 3))
    case 'price':
      return arr.sort((a, b) => a.item.price - b.item.price)
    case 'newest':
      return arr.sort((a, b) => new Date(b.item.createdAt) - new Date(a.item.createdAt))
    default:
      return arr
  }
}

// Full active wishlist ordered by "what you can buy next": already-buyable
// items first, then soonest ETA, cheapest-first as a tiebreak. Powers the
// Dashboard's horizontal "Up next" scroller.
export function getUpNextOrder(items, crumbBalance, weeklyCrumbRate) {
  return items
    .filter((i) => i.status === 'active')
    .map((item) => ({ item, ...getItemStatus(item, crumbBalance, weeklyCrumbRate) }))
    .sort((a, b) => {
      if (a.canBuyNow !== b.canBuyNow) return a.canBuyNow ? -1 : 1
      const aw = a.weeksNeeded ?? Infinity
      const bw = b.weeksNeeded ?? Infinity
      if (aw !== bw) return aw - bw
      return a.item.price - b.item.price
    })
}

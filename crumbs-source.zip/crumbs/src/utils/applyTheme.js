import { getTheme } from '../data/themes'

// Every bg-yellow / text-green-dark / border-ink utility Tailwind generates
// from src/index.css's @theme block resolves through these same CSS custom
// properties, so overriding them on the root element re-colors the whole
// app instantly — no per-component theme prop threading needed.
const CSS_VAR_NAMES = {
  cream: '--color-cream',
  paper: '--color-paper',
  ink: '--color-ink',
  yellow: '--color-yellow',
  yellowDark: '--color-yellow-dark',
  yellowOn: '--color-yellow-on',
  yellowDarkOn: '--color-yellow-dark-on',
  green: '--color-green',
  greenDark: '--color-green-dark',
  greenOn: '--color-green-on',
  greenDarkOn: '--color-green-dark-on',
  coral: '--color-coral',
  coralDark: '--color-coral-dark',
  coralOn: '--color-coral-on',
  coralDarkOn: '--color-coral-dark-on',
  pink: '--color-pink',
  pinkDark: '--color-pink-dark',
  pinkOn: '--color-pink-on',
  pinkDarkOn: '--color-pink-dark-on',
  blue: '--color-blue',
  blueDark: '--color-blue-dark',
  blueOn: '--color-blue-on',
  blueDarkOn: '--color-blue-dark-on',
  purple: '--color-purple',
  purpleDark: '--color-purple-dark',
  purpleOn: '--color-purple-on',
  purpleDarkOn: '--color-purple-dark-on',
}

export function applyTheme(themeId) {
  if (typeof document === 'undefined') return
  const theme = getTheme(themeId)
  const root = document.documentElement
  for (const [key, cssVar] of Object.entries(CSS_VAR_NAMES)) {
    const value = theme.colors[key]
    if (value) root.style.setProperty(cssVar, value)
  }
  root.dataset.theme = theme.id
  root.dataset.themeMode = theme.mode
}

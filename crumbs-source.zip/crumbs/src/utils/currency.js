// Currency formatting helpers. INR-first, but keep it generic so
// Settings > currency could plug in another Intl currency code later.

const formatterCache = new Map()

function getFormatter(currency = 'INR', maximumFractionDigits = 0) {
  const key = `${currency}:${maximumFractionDigits}`
  if (!formatterCache.has(key)) {
    formatterCache.set(
      key,
      new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency,
        maximumFractionDigits,
      })
    )
  }
  return formatterCache.get(key)
}

export function formatCurrency(amount, currency = 'INR') {
  const safe = Number.isFinite(amount) ? amount : 0
  return getFormatter(currency).format(safe)
}

// Compact form for tight spaces, e.g. ₹8,250 stays as-is but very large
// numbers could later collapse to ₹1.2L — not needed for MVP scale, kept
// simple and exact instead.
export function formatCurrencyShort(amount, currency = 'INR') {
  return formatCurrency(amount, currency)
}

export function formatNumber(n) {
  return new Intl.NumberFormat('en-IN').format(Math.round(n || 0))
}

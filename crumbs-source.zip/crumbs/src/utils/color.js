// Small hex<->HSL helpers used only by src/data/themes.js to derive a full,
// consistent 15-token palette from a handful of hand-picked "seed" colors
// per theme, and to compute legible label text for theme swatch previews.

export function hexToHsl(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255
  const g = parseInt(hex.slice(3, 5), 16) / 255
  const b = parseInt(hex.slice(5, 7), 16) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  let h = 0
  let s = 0
  const l = (max + min) / 2
  if (max !== min) {
    const d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0)
        break
      case g:
        h = (b - r) / d + 2
        break
      default:
        h = (r - g) / d + 4
    }
    h /= 6
  }
  return { h: h * 360, s: s * 100, l: l * 100 }
}

export function hslToHex(h, s, l) {
  h = ((h % 360) + 360) % 360
  s = Math.max(0, Math.min(100, s)) / 100
  l = Math.max(0, Math.min(100, l)) / 100
  const c = (1 - Math.abs(2 * l - 1)) * s
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1))
  const m = l - c / 2
  let r = 0
  let g = 0
  let b = 0
  if (h < 60) [r, g, b] = [c, x, 0]
  else if (h < 120) [r, g, b] = [x, c, 0]
  else if (h < 180) [r, g, b] = [0, c, x]
  else if (h < 240) [r, g, b] = [0, x, c]
  else if (h < 300) [r, g, b] = [x, 0, c]
  else [r, g, b] = [c, 0, x]
  const toHex = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0')
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase()
}

// The base accent token doubles as a full card background with `ink` text
// drawn on top of it, so it needs to sit far enough from ink's lightness.
export function bgSafeAccent(hex, mode) {
  const { h, s, l } = hexToHsl(hex)
  const targetL = mode === 'dark' ? Math.min(l, 42) : Math.max(l, 58)
  return hslToHex(h, Math.min(Math.max(s, 30), 65), targetL)
}

// The "-dark" token is used as bold colored TEXT sitting on the paper/cream
// background, so it needs to read clearly against that (not against ink).
export function textSafeAccent(hex, mode) {
  const { h, s, l } = hexToHsl(hex)
  const targetL = mode === 'dark' ? Math.max(l, 62) : Math.min(l, 38)
  return hslToHex(h, Math.max(s, 45), targetL)
}

// Relative luminance (WCAG) -> pick white or near-black label text so it
// reads clearly on top of a given swatch color — mirrors the little
// contrast-matched name label shown at the top of each reference swatch.
export function getContrastText(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255
  const g = parseInt(hex.slice(3, 5), 16) / 255
  const b = parseInt(hex.slice(5, 7), 16) / 255
  const lin = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
  const luminance = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
  return luminance > 0.42 ? '#171310' : '#FFFCF5'
}

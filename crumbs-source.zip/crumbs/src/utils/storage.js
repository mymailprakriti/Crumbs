// Thin localStorage wrapper. Everything the app persists lives under one
// top-level key so export/import/reset are trivial and atomic.
import { defaultCategories } from '../data/initialData'

const STORAGE_KEY = 'crumbs.appData.v1'

export const defaultSettings = {
  currency: 'INR',
  weeklyBudget: 5000,
  savingRateMode: 'manual', // 'manual' | 'auto'
  manualWeeklyCrumbRate: 1000,
  // A goal for the crumb jar balance itself — drives the jar fill gauge
  // in the Crumb breakdown sheet. 0 = no target set yet.
  crumbSavingTarget: 5000,
  // Selected app color theme — see src/data/themes.js.
  themeId: 'classic',
}

export const emptyState = {
  version: 1,
  settings: defaultSettings,
  transactions: [],
  wishlist: [],
  categories: defaultCategories,
  // { [weekKey]: amountManuallyLogged } — the one manual number the app
  // needs since Crumbs deliberately doesn't track your whole budget.
  manualWeeklySpent: {},
  // Wishing Well: free-form wishes/habits that may or may not cost money —
  // see utils/wishes.js. { id, text, status: 'pending'|'achieved',
  // createdAt, lastInteractionAt, achievedAt }
  wishes: [],
}

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return structuredCloneSafe(emptyState)
    const parsed = JSON.parse(raw)
    return {
      ...structuredCloneSafe(emptyState),
      ...parsed,
      settings: { ...defaultSettings, ...(parsed.settings || {}) },
    }
  } catch (e) {
    console.warn('Crumbs: could not read saved data, starting fresh.', e)
    return structuredCloneSafe(emptyState)
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    return true
  } catch (e) {
    console.warn('Crumbs: could not save data.', e)
    return false
  }
}

export function exportStateAsJSON(state) {
  return JSON.stringify(state, null, 2)
}

// Saves the backup file. When this app is running inside a claude.ai
// Artifact frame, the sandbox blocks plain <a download> links, so we use
// the `downloads` runtime capability instead; anywhere else (the app run
// locally, deployed to your own host, etc.) it falls back to a normal
// browser download.
export async function downloadJSON(state, filename = 'crumbs-backup.json') {
  const json = exportStateAsJSON(state)

  if (typeof window !== 'undefined' && window.claude?.use) {
    try {
      const downloads = await window.claude.use('downloads')
      if (downloads) {
        const result = await downloads.save({ filename, data: json })
        return result.status === 'saved'
      }
    } catch (e) {
      // fall through to the normal browser download below
    }
  }

  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
  return true
}

export function parseImportedJSON(text) {
  const parsed = JSON.parse(text)
  if (!parsed || typeof parsed !== 'object') throw new Error('Not a valid Crumbs backup file.')
  return {
    ...structuredCloneSafe(emptyState),
    ...parsed,
    settings: { ...defaultSettings, ...(parsed.settings || {}) },
  }
}

function structuredCloneSafe(obj) {
  return typeof structuredClone === 'function' ? structuredClone(obj) : JSON.parse(JSON.stringify(obj))
}

// Categories are user-editable (see components/CategoryManagerModal), so
// color lookups go through this helper instead of a hardcoded map.
export function getCategoryColor(categories, name) {
  const found = categories?.find((c) => c.name === name)
  return found ? found.color : 'purple'
}

export function getCategoryByName(categories, name) {
  return categories?.find((c) => c.name === name) || null
}

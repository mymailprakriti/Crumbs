// ISO-week helpers used to key "this week's budget" bookkeeping.
// Week starts Monday, matching Intl/ISO convention.

export function startOfWeek(date = new Date()) {
  const d = new Date(date)
  const day = d.getDay() // 0 = Sunday
  const diff = (day === 0 ? -6 : 1) - day // shift to Monday
  d.setDate(d.getDate() + diff)
  d.setHours(0, 0, 0, 0)
  return d
}

export function endOfWeek(date = new Date()) {
  const start = startOfWeek(date)
  const end = new Date(start)
  end.setDate(end.getDate() + 7)
  return end
}

function isoWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()))
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  return Math.ceil(((d - yearStart) / 86400000 + 1) / 7)
}

export function weekKey(date = new Date()) {
  const d = new Date(date)
  const week = isoWeekNumber(d)
  const year = d.getFullYear()
  return `${year}-W${String(week).padStart(2, '0')}`
}

export function isInWeek(dateStr, key = weekKey()) {
  return weekKey(new Date(dateStr)) === key
}

export function daysUntil(dateStr) {
  const target = new Date(dateStr)
  const now = new Date()
  target.setHours(0, 0, 0, 0)
  now.setHours(0, 0, 0, 0)
  return Math.ceil((target - now) / 86400000)
}

export function startOfMonthKey(date = new Date()) {
  const d = new Date(date)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

export function isInMonth(dateStr, key = startOfMonthKey()) {
  return startOfMonthKey(new Date(dateStr)) === key
}

export function weeksAgoKeys(n, from = new Date()) {
  const keys = []
  for (let i = 0; i < n; i++) {
    const d = new Date(from)
    d.setDate(d.getDate() - i * 7)
    keys.push(weekKey(d))
  }
  return keys
}

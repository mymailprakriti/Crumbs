import { useEffect, useMemo, useState } from 'react'
import BottomNav from './components/BottomNav'
import AddCrumbModal from './components/AddCrumbModal'
import WishlistItemModal from './components/WishlistItemModal'
import ItemDetailSheet from './components/ItemDetailSheet'
import CategoryManagerModal from './components/CategoryManagerModal'
import CrumbBreakdownSheet from './components/CrumbBreakdownSheet'
import WishingWellSheet from './components/WishingWellSheet'
import NextUnlockSheet from './components/NextUnlockSheet'
import Dashboard from './screens/Dashboard'
import Wishlist from './screens/Wishlist'
import Planner from './screens/Planner'
import Wallet from './screens/Wallet'
import Settings from './screens/Settings'
import { loadState, saveState, emptyState } from './utils/storage'
import { newId } from './utils/id'
import { getCrumbBalance, getWeeklyCrumbRate, getUpNextOrder } from './utils/calculations'
import { applyTheme } from './utils/applyTheme'

export default function App() {
  const [appState, setAppState] = useState(() => loadState())
  const [tab, setTab] = useState('home')

  const [addCrumbOpen, setAddCrumbOpen] = useState(false)
  const [wishlistModal, setWishlistModal] = useState({ open: false, editing: null })
  const [detailItem, setDetailItem] = useState(null)
  const [categoryManagerOpen, setCategoryManagerOpen] = useState(false)
  const [categoryManagerFocusId, setCategoryManagerFocusId] = useState(null)
  const [crumbBreakdownOpen, setCrumbBreakdownOpen] = useState(false)
  const [wishingWellOpen, setWishingWellOpen] = useState(false)
  const [nextUnlockOpen, setNextUnlockOpen] = useState(false)
  // Bumped once per crumb deposit — the piggy gauges use this to trigger
  // their one-off "coin dropping in" celebration animation.
  const [depositPulse, setDepositPulse] = useState(0)

  useEffect(() => {
    saveState(appState)
  }, [appState])

  const { settings, transactions, wishlist, categories, wishes } = appState

  useEffect(() => {
    applyTheme(settings.themeId)
  }, [settings.themeId])

  const crumbBalance = useMemo(() => getCrumbBalance(transactions), [transactions])
  const weeklyCrumbRate = useMemo(() => getWeeklyCrumbRate(settings, transactions), [settings, transactions])
  const upcomingUnlocks = useMemo(
    () => getUpNextOrder(wishlist, crumbBalance, weeklyCrumbRate).filter((e) => !e.canBuyNow),
    [wishlist, crumbBalance, weeklyCrumbRate]
  )

  // ---- mutators --------------------------------------------------------

  function addTransaction(draft) {
    const tx = {
      id: newId('tx'),
      date: new Date().toISOString(),
      linkedWishlistItemId: null,
      ...draft,
    }
    setAppState((s) => ({ ...s, transactions: [...s.transactions, tx] }))
    if (tx.type === 'deposit') setDepositPulse((p) => p + 1)
  }

  function addWishlistItem(form) {
    const item = {
      id: newId('wish'),
      createdAt: new Date().toISOString(),
      status: 'active',
      image: '',
      targetDate: form.targetDate || null,
      ...form,
    }
    setAppState((s) => ({ ...s, wishlist: [...s.wishlist, item] }))
  }

  function updateWishlistItem(id, patch) {
    setAppState((s) => ({
      ...s,
      wishlist: s.wishlist.map((i) => (i.id === id ? { ...i, ...patch } : i)),
    }))
  }

  function buyWishlistItem(item) {
    const tx = {
      id: newId('tx'),
      type: 'spend',
      amount: item.price,
      source: 'wishlist_purchase',
      note: `Bought ${item.name}`,
      category: item.category,
      date: new Date().toISOString(),
      budgetImpact: false,
      linkedWishlistItemId: item.id,
    }
    setAppState((s) => ({
      ...s,
      transactions: [...s.transactions, tx],
      wishlist: s.wishlist.map((i) => (i.id === item.id ? { ...i, status: 'bought' } : i)),
    }))
    setDetailItem(null)
  }

  function archiveItem(item) {
    updateWishlistItem(item.id, { status: 'archived' })
    setDetailItem(null)
  }

  function deleteItem(item) {
    setAppState((s) => ({ ...s, wishlist: s.wishlist.filter((i) => i.id !== item.id) }))
    setDetailItem(null)
  }

  function updateSettings(patch) {
    setAppState((s) => ({ ...s, settings: { ...s.settings, ...patch } }))
  }

  function resetData() {
    setAppState(structuredCloneSafe(emptyState))
  }

  function importState(parsed) {
    setAppState(parsed)
  }

  // ---- categories ---------------------------------------------------------

  function addCategory(category) {
    setAppState((s) => ({ ...s, categories: [...s.categories, category] }))
  }

  function renameCategory(id, name) {
    setAppState((s) => {
      const old = s.categories.find((c) => c.id === id)
      if (!old) return s
      return {
        ...s,
        categories: s.categories.map((c) => (c.id === id ? { ...c, name } : c)),
        // keep existing wishlist items pointed at the renamed category
        wishlist: s.wishlist.map((i) => (i.category === old.name ? { ...i, category: name } : i)),
      }
    })
  }

  function recolorCategory(id, color) {
    setAppState((s) => ({ ...s, categories: s.categories.map((c) => (c.id === id ? { ...c, color } : c)) }))
  }

  function deleteCategory(id) {
    setAppState((s) => {
      if (s.categories.length <= 1) return s
      const removed = s.categories.find((c) => c.id === id)
      const remaining = s.categories.filter((c) => c.id !== id)
      const fallbackName = remaining[0].name
      return {
        ...s,
        categories: remaining,
        wishlist: s.wishlist.map((i) => (removed && i.category === removed.name ? { ...i, category: fallbackName } : i)),
      }
    })
  }

  function reorderCategories(orderIds) {
    setAppState((s) => {
      const map = new Map(s.categories.map((c) => [c.id, c]))
      const next = orderIds.map((id) => map.get(id)).filter(Boolean)
      for (const c of s.categories) if (!next.includes(c)) next.push(c)
      return { ...s, categories: next }
    })
  }

  function openCategoryEditor(id) {
    setCategoryManagerFocusId(id)
    setCategoryManagerOpen(true)
  }

  // ---- wishing well -------------------------------------------------------

  function addWish(text) {
    const now = new Date().toISOString()
    const wish = { id: newId('coin'), text, status: 'pending', createdAt: now, lastInteractionAt: now, achievedAt: null }
    setAppState((s) => ({ ...s, wishes: [wish, ...s.wishes] }))
  }

  function touchWish(id) {
    setAppState((s) => ({
      ...s,
      wishes: s.wishes.map((w) => (w.id === id ? { ...w, lastInteractionAt: new Date().toISOString() } : w)),
    }))
  }

  function setWishStatus(id, status) {
    setAppState((s) => ({
      ...s,
      wishes: s.wishes.map((w) =>
        w.id === id
          ? {
              ...w,
              status,
              lastInteractionAt: new Date().toISOString(),
              achievedAt: status === 'achieved' ? new Date().toISOString() : null,
            }
          : w
      ),
    }))
  }

  function deleteWish(id) {
    setAppState((s) => ({ ...s, wishes: s.wishes.filter((w) => w.id !== id) }))
  }

  // ---- modal plumbing ----------------------------------------------------

  function openEditItem(item) {
    setDetailItem(null)
    setWishlistModal({ open: true, editing: item })
  }

  function saveWishlistItem(form) {
    if (wishlistModal.editing) {
      updateWishlistItem(wishlistModal.editing.id, form)
    } else {
      addWishlistItem(form)
    }
    setWishlistModal({ open: false, editing: null })
  }

  const screenProps = {
    settings,
    transactions,
    wishlist,
    categories,
    wishes,
    crumbBalance,
    weeklyCrumbRate,
  }

  return (
    <div className="flex h-full flex-col">
      <main className="flex-1 min-h-0 overflow-y-auto overscroll-contain pb-2">
        {tab === 'home' && (
          <Dashboard
            {...screenProps}
            depositPulse={depositPulse}
            onOpenAddCrumb={() => setAddCrumbOpen(true)}
            onOpenAddWishlist={() => setWishlistModal({ open: true, editing: null })}
            onOpenItem={setDetailItem}
            onOpenCrumbBreakdown={() => setCrumbBreakdownOpen(true)}
            onAddWish={addWish}
            onTouchWish={touchWish}
            onSetWishStatus={setWishStatus}
            onOpenWishingWell={() => setWishingWellOpen(true)}
            onOpenNextUnlock={() => setNextUnlockOpen(true)}
            onGoTo={setTab}
          />
        )}
        {tab === 'wishlist' && (
          <Wishlist
            {...screenProps}
            onOpenItem={setDetailItem}
            onAddWishlist={() => setWishlistModal({ open: true, editing: null })}
            onAddCategory={addCategory}
            onReorderCategories={reorderCategories}
            onEditCategory={openCategoryEditor}
          />
        )}
        {tab === 'planner' && (
          <Planner
            {...screenProps}
            onOpenItem={setDetailItem}
            onAddWishlist={() => setWishlistModal({ open: true, editing: null })}
          />
        )}
        {tab === 'wallet' && <Wallet transactions={transactions} crumbBalance={crumbBalance} />}
        {tab === 'settings' && (
          <Settings
            settings={settings}
            onUpdateSettings={updateSettings}
            appState={appState}
            onImportState={importState}
            onResetData={resetData}
            categories={categories}
            onOpenCategoryManager={() => setCategoryManagerOpen(true)}
          />
        )}
      </main>

      <BottomNav active={tab} onChange={setTab} />

      <AddCrumbModal open={addCrumbOpen} onClose={() => setAddCrumbOpen(false)} onSubmit={addTransaction} />

      <WishlistItemModal
        open={wishlistModal.open}
        initial={wishlistModal.editing}
        categories={categories}
        onOpenCategoryManager={() => setCategoryManagerOpen(true)}
        onClose={() => setWishlistModal({ open: false, editing: null })}
        onSave={saveWishlistItem}
      />

      <ItemDetailSheet
        item={detailItem}
        categories={categories}
        crumbBalance={crumbBalance}
        wishlistItems={wishlist}
        weeklyCrumbRate={weeklyCrumbRate}
        onClose={() => setDetailItem(null)}
        onBuy={buyWishlistItem}
        onEdit={openEditItem}
        onArchive={archiveItem}
        onDelete={deleteItem}
      />

      <CategoryManagerModal
        open={categoryManagerOpen}
        focusId={categoryManagerFocusId}
        categories={categories}
        onClose={() => {
          setCategoryManagerOpen(false)
          setCategoryManagerFocusId(null)
        }}
        onAdd={addCategory}
        onRename={renameCategory}
        onRecolor={recolorCategory}
        onDelete={deleteCategory}
      />

      <CrumbBreakdownSheet
        open={crumbBreakdownOpen}
        transactions={transactions}
        crumbBalance={crumbBalance}
        settings={settings}
        onUpdateSettings={updateSettings}
        depositPulse={depositPulse}
        onClose={() => setCrumbBreakdownOpen(false)}
      />

      <WishingWellSheet
        open={wishingWellOpen}
        wishes={wishes}
        transactions={transactions}
        wishlist={wishlist}
        onClose={() => setWishingWellOpen(false)}
        onAdd={addWish}
        onSetStatus={setWishStatus}
        onDelete={deleteWish}
      />

      <NextUnlockSheet
        open={nextUnlockOpen}
        entries={upcomingUnlocks}
        categories={categories}
        crumbBalance={crumbBalance}
        onSelectItem={setDetailItem}
        onClose={() => setNextUnlockOpen(false)}
      />
    </div>
  )
}

function structuredCloneSafe(obj) {
  return typeof structuredClone === 'function' ? structuredClone(obj) : JSON.parse(JSON.stringify(obj))
}
